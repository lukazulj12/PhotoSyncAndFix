package hr.smartduplicatecleaner.core

import hr.smartduplicatecleaner.core.Fixtures.file
import hr.smartduplicatecleaner.core.dates.DateFixPlanner
import hr.smartduplicatecleaner.core.dates.DateFixSettings
import hr.smartduplicatecleaner.core.dates.DateFixStatus
import hr.smartduplicatecleaner.core.dates.DayMonthOrder
import hr.smartduplicatecleaner.core.dates.IntervalBasis
import hr.smartduplicatecleaner.core.dates.NameDateParser
import hr.smartduplicatecleaner.core.dates.NamePattern
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

class NameDateTest {
    private val zone = ZoneId.of("Europe/Zagreb")
    private val today = LocalDate.of(2026, 11, 1)
    private fun parser(order: DayMonthOrder = DayMonthOrder.STANDARD, custom: List<String> = emptyList()) =
        NameDateParser(order, custom, detectTimestamps = true, zone = zone, today = today)

    @Test
    fun userExamples() {
        val p = parser()
        val wa = p.parse("IMG-20261028-WA0014.JPG")!!
        assertEquals(LocalDate.of(2026, 10, 28), wa.date)
        assertNull(wa.time)
        val vid = p.parse("VID_20250705_105923_016.MP4")!!
        assertEquals(LocalDate.of(2025, 7, 5), vid.date)
        assertEquals(LocalTime.of(10, 59, 23), vid.time)
        assertTrue(vid.ambiguous) // 07 i 05 su zamjenjivi – pročitano standardno GGGGMMDD
    }

    @Test
    fun commonFormats() {
        val p = parser()
        assertEquals(LocalDateTime.of(2025, 7, 5, 10, 59, 23),
            p.parse("Screenshot_2025-07-05-10-59-23-123_com.whatsapp.jpg")!!.let { it.toDateTime(LocalTime.NOON) })
        assertEquals(LocalDate.of(2024, 12, 31), p.parse("PXL_20241231_235959123.jpg")!!.date)
        assertEquals(LocalDate.of(2023, 1, 15), p.parse("IMG_20230115_120000.jpg")!!.date)
        assertEquals(LocalDate.of(2023, 1, 15), p.parse("photo 15.01.2023.jpg")!!.date)
        assertEquals(LocalDate.of(2023, 1, 15), p.parse("scan_15-01-2023.pdf")!!.date)
        assertEquals(LocalDate.of(2022, 3, 4), p.parse("20220304_101010.jpg")!!.date)
        // Unix vrijeme u milisekundama (npr. Telegram/Facebook): 1700000000000 = 14. 11. 2023.
        assertEquals(LocalDate.of(2023, 11, 14), p.parse("FB_IMG_1700000000000.jpg")!!.date)
    }

    @Test
    fun noDateOrImplausible_returnsNull() {
        val p = parser()
        assertNull(p.parse("DSC_0042.JPG"))
        assertNull(p.parse("IMG-WA0014.jpg"))
        assertNull(p.parse("IMG_20271231.jpg"))      // budućnost
        assertNull(p.parse("IMG_19850101.jpg"))      // prije 1990.
        assertNull(p.parse("file_20251399.jpg"))     // nemoguć datum
        assertNull(p.parse("123456789012345678.jpg"))
    }

    @Test
    fun ddmmVsMmdd() {
        // 28 ne može biti mjesec → jedino moguće tumačenje, bez obzira na postavku.
        assertEquals(LocalDate.of(2026, 10, 28), parser(DayMonthOrder.MONTH_FIRST).parse("img_28102026.jpg")!!.date)
        assertEquals(LocalDate.of(2026, 10, 28), parser(DayMonthOrder.STANDARD).parse("img_10282026.jpg")!!.date)
        assertFalse(parser().parse("img_10282026.jpg")!!.ambiguous)
        assertEquals(LocalDate.of(2026, 10, 28), parser().parse("IMG_20262810.jpg")!!.date) // GGGGDDMM
        // Zamjenjivo (05 i 07): odluka prema postavci.
        assertEquals(LocalDate.of(2025, 7, 5), parser(DayMonthOrder.STANDARD).parse("x_05072025.jpg")!!.date)
        assertEquals(LocalDate.of(2025, 5, 7), parser(DayMonthOrder.MONTH_FIRST).parse("x_05072025.jpg")!!.date)
        assertEquals(LocalDate.of(2025, 7, 5), parser(DayMonthOrder.DAY_FIRST).parse("x_05072025.jpg")!!.date)
        assertEquals(LocalDate.of(2025, 5, 7), parser(DayMonthOrder.DAY_FIRST).parse("IMG_20250705.jpg")!!.date)
        assertNull(parser(DayMonthOrder.SKIP_AMBIGUOUS).parse("x_05072025.jpg"))
        assertEquals(LocalDate.of(2025, 7, 7), parser(DayMonthOrder.SKIP_AMBIGUOUS).parse("IMG_20250707.jpg")!!.date)
    }

    @Test
    fun customPatterns() {
        val p = parser(custom = listOf("Snimka yy-MM-dd HH.mm*", "IMG-ddMMyyyy-WA*"))
        val a = p.parse("Snimka 25-07-05 10.59 (2).jpg")!!
        assertEquals(LocalDate.of(2025, 7, 5), a.date)
        assertEquals(LocalTime.of(10, 59), a.time)
        assertEquals("Snimka yy-MM-dd HH.mm*", a.source)
        // Ručni uzorak ima prednost pred automatskim prepoznavanjem.
        assertEquals(LocalDate.of(2025, 7, 5), p.parse("IMG-05072025-WA0001.jpg")!!.date)
        assertEquals(LocalDate.of(2025, 5, 7), parser(DayMonthOrder.MONTH_FIRST).parse("IMG-05072025-WA0001.jpg")!!.date)
        for ((pattern, reason) in listOf(
            "IMG-MMdd*" to NamePattern.Reason.MISSING_YEAR,
            "yyyyMM*" to NamePattern.Reason.MISSING_DAY,
            "yyyy-MM-dd-yyyy" to NamePattern.Reason.DUPLICATE_TOKEN,
            "  " to NamePattern.Reason.EMPTY
        )) {
            try { NamePattern.compile(pattern); fail(pattern) } catch (e: NamePattern.InvalidPatternException) { assertEquals(reason, e.reason) }
        }
    }

    @Test
    fun planner_detectsMismatch_andSkipsNamesWithoutDate() {
        val z = zone
        fun millis(y: Int, m: Int, d: Int, h: Int = 12) = LocalDateTime.of(y, m, d, h, 0).atZone(z).toInstant().toEpochMilli()
        val copied = file("WhatsApp/IMG-20261028-WA0014.jpg", 10, modified = millis(2026, 11, 1, 9))
        val correct = file("DCIM/VID_20250705_105923.mp4", 10, modified = millis(2025, 7, 5, 11), taken = millis(2025, 7, 5, 11))
        val noDate = file("DCIM/DSC_0042.jpg", 10, modified = millis(2026, 1, 1))
        val p = parser()
        val items = DateFixPlanner.plan(listOf(copied, correct, noDate), p, DateFixSettings(), z)
        val c = items[0]
        assertEquals(DateFixStatus.NEEDS_FIX, c.status)
        // Naziv bez vremena: zadržava se dosadašnje vrijeme u danu (09:00), datum iz naziva.
        assertEquals(millis(2026, 10, 28, 9), c.targetMillis)
        assertEquals(DateFixStatus.OK, items[1].status)
        assertEquals(DateFixStatus.NO_DATE_IN_NAME, items[2].status)

        // Interval po datumu iz naziva: samo 2025.
        val only2025 = DateFixSettings(from = millis(2025, 1, 1, 0), to = millis(2025, 12, 31, 23))
        val r = DateFixPlanner.plan(listOf(copied, correct), p, only2025, z)
        assertEquals(DateFixStatus.OUT_OF_INTERVAL, r[0].status)
        assertEquals(DateFixStatus.OK, r[1].status)
        // Interval po trenutačnom datumu (studeni 2026.) → WhatsApp slika je unutra.
        val nov = DateFixSettings(from = millis(2026, 11, 1, 0), basis = IntervalBasis.CURRENT_DATE)
        assertEquals(DateFixStatus.NEEDS_FIX, DateFixPlanner.plan(listOf(copied), p, nov, z)[0].status)
        // Usporedba s vremenom: isti dan, različito vrijeme.
        val timeOff = file("DCIM/VID_20250705_105923.mp4", 10, modified = millis(2025, 7, 5, 15), taken = millis(2025, 7, 5, 15))
        assertEquals(DateFixStatus.OK, DateFixPlanner.plan(listOf(timeOff), p, DateFixSettings(), z)[0].status)
        assertEquals(DateFixStatus.NEEDS_FIX, DateFixPlanner.plan(listOf(timeOff), p, DateFixSettings(compareTime = true), z)[0].status)
    }
}
