package hr.smartduplicatecleaner.core.dates

import java.time.DateTimeException
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId

/**
 * Što učiniti kad su dan i mjesec zamjenjivi (oba ≤ 12, npr. 05.07.).
 * Kad je samo jedno tumačenje moguće (npr. 28.10. – mjesec ne može biti 28), uvijek se koristi to tumačenje.
 */
enum class DayMonthOrder {
    /** GGGGMMDD (npr. IMG_20250705) i DDMMGGGG (europski zapis) – zadano. */
    STANDARD,
    /** Mjesec prije dana: GGGGMMDD i MMDDGGGG (američki zapis). */
    MONTH_FIRST,
    /** Dan prije mjeseca: GGGGDDMM i DDMMGGGG. */
    DAY_FIRST,
    /** Dvosmislene datume preskoči. */
    SKIP_AMBIGUOUS
}

/** Datum pročitan iz naziva datoteke. */
data class NameDate(
    val date: LocalDate,
    /** Vrijeme iz naziva ili null ako ga nema (npr. IMG-20261028-WA0014). */
    val time: LocalTime?,
    /** "auto", "timestamp" ili tekst ručnog uzorka koji je prepoznao datum. */
    val source: String,
    /** Dan i mjesec bili su zamjenjivi – odluka je donesena prema postavci [DayMonthOrder]. */
    val ambiguous: Boolean
) {
    fun toDateTime(defaultTime: LocalTime): LocalDateTime = LocalDateTime.of(date, time ?: defaultTime)
}

/**
 * Prepoznavanje datuma u nazivu datoteke.
 *
 * Redoslijed: ručni uzorci (redom kako su zadani) → GGGG MM DD (npr. IMG_20250705, VID_20250705_105923,
 * Screenshot_2025-07-05-10-59-23) → DD MM GGGG (npr. 05.07.2025) → Unix vrijeme u milisekundama (13 znamenki).
 * Prihvaćaju se samo stvarni datumi od [minYear] do danas (+1 dan); sve ostalo se zanemaruje.
 */
class NameDateParser(
    private val order: DayMonthOrder = DayMonthOrder.STANDARD,
    customPatterns: List<String> = emptyList(),
    private val detectTimestamps: Boolean = true,
    private val zone: ZoneId = ZoneId.systemDefault(),
    private val today: LocalDate = LocalDate.now(zone),
    private val minYear: Int = 1990
) {
    private val custom: List<NamePattern> = customPatterns.mapNotNull { NamePattern.compileOrNull(it) }

    fun parse(fileName: String): NameDate? {
        for (p in custom) {
            val f = p.match(fileName) ?: continue
            val d = date(f.year, f.month, f.day) ?: continue
            return NameDate(d, time(f.hour, f.minute, f.second), p.text, ambiguous = false)
        }
        val base = fileName.substringBeforeLast('.', fileName)
        for (m in YEAR_FIRST.findAll(base)) {
            val y = m.groupValues[1].toInt()
            val r = resolve(y, m.groupValues[3].toInt(), m.groupValues[4].toInt(), yearFirst = true) ?: continue
            return NameDate(r.first, timeOf(m.groupValues[5], m.groupValues[6], m.groupValues[7]), "auto", r.second)
        }
        for (m in YEAR_LAST.findAll(base)) {
            val y = m.groupValues[4].toInt()
            val r = resolve(y, m.groupValues[1].toInt(), m.groupValues[3].toInt(), yearFirst = false) ?: continue
            return NameDate(r.first, timeOf(m.groupValues[5], m.groupValues[6], m.groupValues[7]), "auto", r.second)
        }
        if (detectTimestamps) {
            for (m in TIMESTAMP_MS.findAll(base)) {
                val dt = try {
                    LocalDateTime.ofInstant(Instant.ofEpochMilli(m.groupValues[1].toLong()), zone)
                } catch (e: DateTimeException) { continue }
                if (!plausible(dt.toLocalDate())) continue
                return NameDate(dt.toLocalDate(), dt.toLocalTime().withNano(0), "timestamp", ambiguous = false)
            }
        }
        return null
    }

    /**
     * Tumačenje dvaju dvoznamenkastih polja (a, b) uz godinu.
     * Standardno: godina naprijed → a = mjesec, b = dan; godina na kraju → a = dan, b = mjesec.
     */
    private fun resolve(year: Int, a: Int, b: Int, yearFirst: Boolean): Pair<LocalDate, Boolean>? {
        val std = if (yearFirst) date(year, a, b) else date(year, b, a)
        val swp = if (yearFirst) date(year, b, a) else date(year, a, b)
        if (std == null && swp == null) return null
        if (std == null) return swp!! to false
        if (swp == null || swp == std) return std to false
        return when (order) {
            DayMonthOrder.STANDARD -> std to true
            DayMonthOrder.MONTH_FIRST -> (if (yearFirst) std else swp) to true
            DayMonthOrder.DAY_FIRST -> (if (yearFirst) swp else std) to true
            DayMonthOrder.SKIP_AMBIGUOUS -> null
        }
    }

    private fun date(y: Int, m: Int, d: Int): LocalDate? {
        if (m !in 1..12 || d !in 1..31) return null
        val ld = try { LocalDate.of(y, m, d) } catch (e: DateTimeException) { return null }
        return if (plausible(ld)) ld else null
    }

    private fun plausible(d: LocalDate) = d.year >= minYear && !d.isAfter(today.plusDays(1))

    private fun time(h: Int?, m: Int?, s: Int?): LocalTime? {
        if (h == null || m == null) return null
        if (h !in 0..23 || m !in 0..59) return null
        val sec = s ?: 0
        if (sec !in 0..59) return null
        return LocalTime.of(h, m, sec)
    }

    private fun timeOf(h: String, m: String, s: String): LocalTime? =
        if (h.isEmpty() || m.isEmpty()) null else time(h.toInt(), m.toInt(), s.ifEmpty { null }?.toInt())

    companion object {
        /** Vrijeme nakon datuma: HH mm [ss] [milisekunde], npr. _105923, -10-59-23, _105923123, _105923_016. */
        private const val TIME = "(?:[-_ T.]?(\\d{2})[-_.:]?(\\d{2})(?:[-_.:]?(\\d{2})(?:[-_.,]?\\d{1,3})?)?)?"
        private val YEAR_FIRST = Regex("(?<!\\d)((?:19|20)\\d{2})([-_.]?)(\\d{2})\\2(\\d{2})$TIME(?!\\d)")
        private val YEAR_LAST = Regex("(?<!\\d)(\\d{2})([-_.]?)(\\d{2})\\2((?:19|20)\\d{2})$TIME(?!\\d)")
        private val TIMESTAMP_MS = Regex("(?<!\\d)(1[3-9]\\d{11})(?!\\d)")
    }
}
