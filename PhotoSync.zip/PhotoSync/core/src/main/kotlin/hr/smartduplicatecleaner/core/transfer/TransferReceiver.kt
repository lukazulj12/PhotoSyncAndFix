package hr.smartduplicatecleaner.core.transfer

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Collections
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Primatelj. Sluša na [port], prihvaća samo pošiljatelja koji dokaže da zna kod za uparivanje
 * (HMAC-SHA256 nad slučajnim izazovom – kod se nikad ne šalje mrežom). Istodobno je moguća samo jedna sesija.
 * Nakon završene sesije nastavlja slušati dok se ne pozove [stop].
 */
class TransferReceiver(
    code: String,
    private val sink: TransferSink,
    private val listener: Listener,
    private val port: Int = PairingCode.PORT
) {
    interface Listener {
        fun onSessionStarted(deviceName: String, files: Int, bytes: Long) {}
        fun onProgress(progress: TransferProgress) {}
        fun onSessionFinished(result: TransferResult) {}
        /** Primatelj nije mogao primiti datoteke (nema mjesta) – sesija odbijena. */
        fun onRejectedNoSpace(needed: Long, free: Long) {}
        /** Previše pogrešnih kodova – primatelj je zaustavljen (zaštita od pogađanja koda). */
        fun onTooManyAttempts() {}
    }

    private val key = PairingCode.authKey(code)
    private val random = SecureRandom()
    private val session = AtomicReference<Session?>(null)
    private var server: ServerSocket? = null
    private var executor: ExecutorService? = null
    @Volatile private var running = false
    private val failedAttempts = AtomicInteger()
    private val openSockets: MutableSet<Socket> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    private inner class Session(val deviceName: String) {
        val started = System.currentTimeMillis()
        lateinit var items: Map<Int, TransferItem>
        var skipped: List<TransferItem> = emptyList()
        var filesTotal = 0
        var bytesTotal = 0L
        val ok: MutableList<TransferItem> = Collections.synchronizedList(mutableListOf())
        val failed: MutableList<Pair<TransferItem, String>> = Collections.synchronizedList(mutableListOf())
        val bytes = AtomicLong()
        val activeData = AtomicInteger()
        val lastEmit = AtomicLong()
        val lock = Object()

        fun progress(force: Boolean = false) {
            val now = System.currentTimeMillis()
            val last = lastEmit.get()
            if (force || now - last >= 200 && lastEmit.compareAndSet(last, now)) {
                listener.onProgress(TransferProgress(ok.size + failed.size, filesTotal, bytes.get(), bytesTotal, failed.size, started))
            }
        }

        fun dataFinished() {
            activeData.decrementAndGet()
            synchronized(lock) { lock.notifyAll() }
        }

        fun awaitDataIdle(timeoutMs: Long) {
            val end = System.currentTimeMillis() + timeoutMs
            synchronized(lock) {
                while (activeData.get() > 0) {
                    val left = end - System.currentTimeMillis()
                    if (left <= 0) return
                    lock.wait(left)
                }
            }
        }

        fun result(cancelled: Boolean) =
            TransferResult(ok.toList(), failed.toList(), skipped, bytes.get(), System.currentTimeMillis() - started, cancelled)
    }

    /** Pokreće slušanje; vraća stvarni port. */
    fun start(): Int {
        val s = ServerSocket()
        s.reuseAddress = true
        // Veličinu međuspremnika ne postavljamo ručno – sustav je tada automatski prilagođava brzini veze.
        s.bind(InetSocketAddress(port))
        server = s
        val ex = Executors.newCachedThreadPool()
        executor = ex
        running = true
        ex.execute {
            while (running) {
                val socket = try { s.accept() } catch (e: Exception) { break }
                try {
                    ex.execute { handle(socket) }
                } catch (e: Exception) {
                    try { socket.close() } catch (x: Exception) { }
                }
            }
        }
        return s.localPort
    }

    /** Zaustavlja slušanje i prekida sve otvorene veze (djelomične datoteke se odbacuju). */
    fun stop() {
        running = false
        try { server?.close() } catch (e: Exception) { }
        openSockets.forEach { try { it.close() } catch (e: Exception) { } }
        executor?.shutdownNow()
    }

    val isRunning: Boolean get() = running

    private fun handle(socket: Socket) {
        openSockets += socket
        try {
            socket.tcpNoDelay = true
            socket.soTimeout = 30_000
            val inp = DataInputStream(BufferedInputStream(socket.getInputStream(), Proto.BUFFER))
            val out = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), 64 * 1024))
            val magic = ByteArray(Proto.MAGIC.size)
            inp.readFully(magic)
            if (!magic.contentEquals(Proto.MAGIC)) return
            val type = inp.readUnsignedByte()
            if (type != Proto.TYPE_CONTROL && type != Proto.TYPE_DATA && type != Proto.TYPE_SPEED) return
            val nonce = ByteArray(16).also { random.nextBytes(it) }
            out.write(nonce)
            out.flush()
            val mac = ByteArray(32)
            inp.readFully(mac)
            if (!MessageDigest.isEqual(mac, Proto.hmac(key, Proto.label(type), nonce))) {
                out.writeByte(Proto.AUTH_FAIL); out.flush()
                if (failedAttempts.incrementAndGet() >= PairingCode.MAX_FAILED_ATTEMPTS && running) {
                    stop()
                    listener.onTooManyAttempts()
                }
                return
            }
            when (type) {
                Proto.TYPE_CONTROL -> handleControl(socket, inp, out)
                Proto.TYPE_DATA -> handleData(socket, inp, out)
                else -> handleSpeed(socket, inp, out)
            }
        } catch (e: Exception) {
            // Prekinuta ili neispravna veza – zanemaruje se.
        } finally {
            try { socket.close() } catch (e: Exception) { }
            openSockets -= socket
        }
    }

    private fun handleControl(socket: Socket, inp: DataInputStream, out: DataOutputStream) {
        val sess = Session("")
        if (!session.compareAndSet(null, sess)) {
            out.writeByte(Proto.BUSY); out.flush(); return
        }
        var finished = false
        try {
            out.writeByte(Proto.OK); out.flush()
            val name = inp.readUTF()
            val count = inp.readInt()
            if (count < 0 || count > Proto.MAX_ITEMS) return
            val items = List(count) { Proto.readItem(inp) }
            val skip = items.filter { runCatching { sink.shouldSkip(it) }.getOrDefault(false) }
            val skipIds = skip.map { it.id }.toHashSet()
            val accepted = items.filter { it.id !in skipIds }
            val need = accepted.sumOf { it.size }
            val free = runCatching { sink.freeBytes() }.getOrDefault(Long.MAX_VALUE)
            if (need > free) {
                out.writeByte(Proto.NO_SPACE); out.writeLong(free); out.flush()
                listener.onRejectedNoSpace(need, free)
                return
            }
            sess.items = items.associateBy { it.id }
            sess.skipped = skip
            sess.filesTotal = accepted.size
            sess.bytesTotal = need
            listener.onSessionStarted(name.ifBlank { socket.inetAddress?.hostAddress ?: "" }, accepted.size, need)
            sess.progress(force = true)
            out.writeByte(Proto.OK)
            out.writeLong(free)
            out.writeInt(skip.size)
            skip.forEach { out.writeInt(it.id) }
            out.flush()

            socket.soTimeout = 0
            val cmd = inp.read() // DONE ili -1 ako je pošiljatelj prekinuo
            sess.awaitDataIdle(60_000)
            if (cmd == Proto.DONE) {
                out.writeInt(sess.ok.size); out.writeInt(sess.failed.size); out.flush()
            }
            sess.progress(force = true)
            finished = true
            listener.onSessionFinished(sess.result(cancelled = cmd != Proto.DONE))
        } finally {
            if (!finished && sessionInitialized(sess)) {
                sess.awaitDataIdle(5_000)
                listener.onSessionFinished(sess.result(cancelled = true))
            }
            session.compareAndSet(sess, null)
        }
    }

    private fun sessionInitialized(s: Session): Boolean = try { s.items; true } catch (e: UninitializedPropertyAccessException) { false }

    /**
     * Podatkovna veza. Datoteke stižu jedna za drugom bez čekanja; spremanje (zatvaranje, upis datuma, MediaStore)
     * radi se u pozadinskoj dretvi dok se već prima sljedeća datoteka, a potvrda (id + uspjeh) šalje se kad je
     * datoteka spremljena. Tako ni spremanje ni kašnjenje mreže ne zaustavljaju tok podataka.
     */
    private fun handleData(socket: Socket, inp: DataInputStream, out: DataOutputStream) {
        val sess = session.get()
        if (sess == null || !sessionInitialized(sess)) {
            out.writeByte(Proto.BAD); out.flush(); return
        }
        sess.activeData.incrementAndGet()
        val committer = Executors.newSingleThreadExecutor { r -> Thread(r, "photosync-commit").apply { isDaemon = true } }
        // Ograničenje datoteka koje čekaju spremanje (da disk ne zaostane previše za mrežom).
        val pending = java.util.concurrent.Semaphore(4)
        val outLock = Any()
        fun ack(id: Int, ok: Boolean) {
            try {
                synchronized(outLock) { out.writeInt(id); out.writeByte(if (ok) 0 else 1); out.flush() }
            } catch (e: Exception) {
                // Veza prekinuta – pošiljatelj će nepotvrđene stavke označiti kao neuspjele.
            }
        }
        fun record(item: TransferItem?, error: String?) {
            if (item != null) {
                if (error == null) sess.ok += item else sess.failed += item to error
            }
            sess.progress()
        }
        var current: TransferItem? = null
        var incoming: IncomingFile? = null
        try {
            synchronized(outLock) { out.writeByte(Proto.OK); out.flush() }
            socket.soTimeout = 120_000
            val buf = ByteArray(Proto.BUFFER)
            while (true) {
                val id = inp.readInt()
                if (id == Proto.END) break
                val size = inp.readLong()
                val item = sess.items[id]
                current = item
                var error: String? = if (item == null || item.size != size) "unknown" else null
                incoming = null
                if (error == null) {
                    incoming = try { sink.create(item!!) } catch (e: Exception) { error = "create: " + (e.message ?: e.javaClass.simpleName); null }
                }
                var left = size
                while (left > 0) {
                    val n = inp.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (n < 0) throw EOFException()
                    if (error == null) {
                        try { incoming!!.output.write(buf, 0, n) } catch (e: Exception) { error = "write: " + (e.message ?: e.javaClass.simpleName) }
                    }
                    left -= n
                    if (item != null) { sess.bytes.addAndGet(n.toLong()); sess.progress() }
                }
                if (inp.readUnsignedByte() != 0 && error == null) error = "sender"
                val file = incoming
                incoming = null
                current = null
                if (error != null || file == null) {
                    try { file?.abort() } catch (e: Exception) { }
                    record(item, error ?: "unknown")
                    ack(id, false)
                } else {
                    pending.acquire()
                    committer.execute {
                        try {
                            var commitError: String? = null
                            try { file.commit() } catch (e: Exception) {
                                commitError = "commit: " + (e.message ?: e.javaClass.simpleName)
                                try { file.abort() } catch (x: Exception) { }
                            }
                            record(item, commitError)
                            ack(id, commitError == null)
                        } finally {
                            pending.release()
                        }
                    }
                }
            }
            // Pričekaj spremanje preostalih datoteka, zatim oznaka kraja potvrda.
            committer.shutdown()
            committer.awaitTermination(10, java.util.concurrent.TimeUnit.MINUTES)
            synchronized(outLock) { out.writeInt(Proto.END); out.flush() }
        } catch (e: Exception) {
            try { incoming?.abort() } catch (x: Exception) { }
            current?.let { sess.failed += it to "connection" }
        } finally {
            // Datoteke koje su već potpuno primljene spremaju se i kad se veza prekine.
            committer.shutdown()
            try { committer.awaitTermination(2, java.util.concurrent.TimeUnit.MINUTES) } catch (e: Exception) { }
            sess.dataFinished()
        }
    }

    /** Test brzine: broji primljene bajtove do kraja toka i vraća zbroj. Ne dira disk ni sesiju. */
    private fun handleSpeed(socket: Socket, inp: DataInputStream, out: DataOutputStream) {
        out.writeByte(Proto.OK); out.flush()
        socket.soTimeout = 30_000
        val buf = ByteArray(Proto.BUFFER)
        var total = 0L
        while (true) {
            val n = inp.read(buf)
            if (n < 0) break
            total += n
        }
        out.writeLong(total)
        out.flush()
    }
}
