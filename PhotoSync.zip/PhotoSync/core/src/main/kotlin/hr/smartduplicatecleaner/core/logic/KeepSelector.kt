package hr.smartduplicatecleaner.core.logic

import hr.smartduplicatecleaner.core.model.CriterionType
import hr.smartduplicatecleaner.core.model.DatePreference
import hr.smartduplicatecleaner.core.model.DuplicateGroup
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.FolderPriority
import hr.smartduplicatecleaner.core.model.GroupType
import hr.smartduplicatecleaner.core.model.KeepRules
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.model.SizePreference

/** Šifre razloga – sučelje ih prevodi na hrvatski ili engleski. */
enum class ReasonCode {
    KEEP_OLDER, KEEP_NEWER, KEEP_LARGER, KEEP_SMALLER, KEEP_HIGHER_RES,
    /** Zadržana jer je u mapi višeg prioriteta (arg = povlaštena mapa ili null ako su ostale podređene). */
    KEEP_FOLDER_PRIORITY,
    DEL_NEWER, DEL_OLDER, DEL_SMALLER, DEL_LARGER, DEL_LOWER_RES,
    /** Predložena za brisanje jer je u mapi nižeg prioriteta (arg = mapa datoteke). */
    DEL_FOLDER_PRIORITY,
    /** Za usporedbu je korišten zamjenski datum (arg = izvor datuma). */
    DATE_FALLBACK_USED,
    /** Kriterij preskočen jer nekoj datoteci nedostaju podaci (arg = kriterij). */
    SKIPPED_MISSING_DATA,
    NO_CLEAR_WINNER,
    DIFFERENT_CONTENT,
    SIMILAR_ONLY,
    NO_RULES,
    MANUAL_CHOICE
}

data class Reason(val code: ReasonCode, val arg: String? = null) {
    fun encode(): String = if (arg == null) code.name else "${code.name}:$arg"

    companion object {
        fun decode(text: String): Reason? {
            val code = text.substringBefore(':')
            val arg = text.substringAfter(':', "").ifEmpty { null }
            return ReasonCode.entries.firstOrNull { it.name == code }?.let { Reason(it, arg) }
        }

        fun encodeList(list: List<Reason>): String = list.joinToString("|") { it.encode() }
        fun decodeList(text: String?): List<Reason> =
            text.orEmpty().split('|').filter { it.isNotBlank() }.mapNotNull { decode(it) }
    }
}

enum class Suggestion { KEEP, DELETE, UNDECIDED }

data class MemberDecision(val fileKey: String, val suggestion: Suggestion, val reasons: List<Reason>)

data class GroupDecision(
    val groupId: String,
    val members: List<MemberDecision>,
    /** true = nema jasnog pobjednika ili grupa ne dopušta automatski prijedlog; ništa se ne označava. */
    val needsManual: Boolean,
    val notes: List<Reason>
) {
    val suggestedDeleteKeys: Set<String>
        get() = members.filter { it.suggestion == Suggestion.DELETE }.map { it.fileKey }.toSet()
}

/**
 * Automatski odabir datoteke koju treba zadržati.
 *
 * Kriteriji se primjenjuju redom prioriteta. Svaki kriterij zadržava samo najbolje kandidate;
 * ako na kraju ostane točno jedan – on se zadržava, a ostali se predlažu za brisanje.
 * Ako ih ostane više, aplikacija NE predlaže ništa i traži ručnu odluku.
 * Ako nekoj datoteci nedostaju podaci za kriterij, kriterij se preskače (ne nagađa se).
 */
object KeepSelector {
    private const val DATE_TOLERANCE_MS = 2_000.0

    fun decide(group: DuplicateGroup, files: Map<String, ScannedFile>, rules: KeepRules): GroupDecision {
        val members = group.fileKeys.mapNotNull { files[it] }
        if (members.size < 2) {
            return GroupDecision(group.id, members.map { MemberDecision(it.key, Suggestion.KEEP, emptyList()) }, true, emptyList())
        }
        if (!group.allowsAutoSuggestion) {
            val code = if (group.type == GroupType.SAME_NAME) ReasonCode.DIFFERENT_CONTENT else ReasonCode.SIMILAR_ONLY
            return GroupDecision(
                group.id,
                members.map { MemberDecision(it.key, Suggestion.UNDECIDED, listOf(Reason(code))) },
                needsManual = true,
                notes = listOf(Reason(code))
            )
        }

        val notes = mutableListOf<Reason>()
        val memberReasons = members.associate { it.key to mutableListOf<Reason>() }
        val eliminated = LinkedHashMap<String, Reason>()
        val keeperReasons = mutableListOf<Reason>()
        var candidates = members
        val enabled = rules.normalizedOrder().filter { rules.isEnabled(it) }

        if (enabled.isEmpty()) notes += Reason(ReasonCode.NO_RULES)

        for (criterion in enabled) {
            if (candidates.size <= 1) break
            val evaluation = evaluate(criterion, candidates, rules, group.category) ?: continue
            if (evaluation.missingData) {
                notes += Reason(ReasonCode.SKIPPED_MISSING_DATA, criterion.name)
                continue
            }
            evaluation.fallbackKeys.forEach { (key, source) ->
                memberReasons[key]?.let { list ->
                    val r = Reason(ReasonCode.DATE_FALLBACK_USED, source)
                    if (r !in list) list += r
                }
            }
            val best = evaluation.scores.values.max()
            val winners = candidates.filter { evaluation.scores.getValue(it.key) >= best - evaluation.tolerance }
            if (winners.size < candidates.size) {
                candidates.filter { it !in winners }.forEach {
                    eliminated.putIfAbsent(it.key, Reason(evaluation.loseCode, evaluation.args[it.key]))
                }
                val winKey = winners.first().key
                val keepReason = Reason(evaluation.winCode, if (evaluation.winArgs != null) evaluation.winArgs[winKey] else evaluation.args[winKey])
                if (keepReason !in keeperReasons) keeperReasons += keepReason
            }
            candidates = winners
        }

        if (candidates.size == 1) {
            val keeper = candidates.first()
            val decisions = members.map { f ->
                if (f.key == keeper.key) {
                    MemberDecision(f.key, Suggestion.KEEP, keeperReasons + memberReasons.getValue(f.key))
                } else {
                    val reason = eliminated[f.key]
                    // Sigurnosna provjera: datoteka bez razloga eliminacije ne smije se predložiti za brisanje.
                    if (reason == null) MemberDecision(f.key, Suggestion.UNDECIDED, memberReasons.getValue(f.key))
                    else MemberDecision(f.key, Suggestion.DELETE, listOf(reason) + memberReasons.getValue(f.key))
                }
            }
            val manual = decisions.none { it.suggestion == Suggestion.DELETE }
            return GroupDecision(group.id, decisions, manual, notes)
        }

        // Nema jasnog pobjednika – ništa se ne označava za brisanje.
        notes += Reason(ReasonCode.NO_CLEAR_WINNER)
        val decisions = members.map { f ->
            val info = listOfNotNull(eliminated[f.key]) + memberReasons.getValue(f.key) +
                if (f in candidates) listOf(Reason(ReasonCode.NO_CLEAR_WINNER)) else emptyList()
            MemberDecision(f.key, Suggestion.UNDECIDED, info)
        }
        return GroupDecision(group.id, decisions, needsManual = true, notes = notes)
    }

    private class Evaluation(
        val scores: Map<String, Double>,
        val tolerance: Double,
        val winCode: ReasonCode,
        val loseCode: ReasonCode,
        val args: Map<String, String?> = emptyMap(),
        /** Argumenti razloga za pobjednika, ako se razlikuju od [args]. */
        val winArgs: Map<String, String?>? = null,
        val fallbackKeys: Map<String, String> = emptyMap(),
        val missingData: Boolean = false
    )

    private val MISSING = Evaluation(emptyMap(), 0.0, ReasonCode.NO_RULES, ReasonCode.NO_RULES, missingData = true)

    /** @return null ako kriterij nije primjenjiv na ovu kategoriju (tiho se preskače). */
    private fun evaluate(
        criterion: CriterionType,
        candidates: List<ScannedFile>,
        rules: KeepRules,
        category: FileCategory
    ): Evaluation? = when (criterion) {
        CriterionType.DATE -> {
            val resolved = candidates.associate { it.key to DateResolver.resolve(it, rules.dateKind) }
            if (resolved.values.any { it == null }) MISSING else {
                val older = rules.datePreference == DatePreference.OLDER
                Evaluation(
                    scores = resolved.mapValues { (_, d) -> if (older) -d!!.millis.toDouble() else d!!.millis.toDouble() },
                    tolerance = DATE_TOLERANCE_MS,
                    winCode = if (older) ReasonCode.KEEP_OLDER else ReasonCode.KEEP_NEWER,
                    loseCode = if (older) ReasonCode.DEL_NEWER else ReasonCode.DEL_OLDER,
                    args = resolved.mapValues { (_, d) -> d!!.source.name },
                    fallbackKeys = resolved.filterValues { it!!.isFallback }.mapValues { (_, d) -> d!!.source.name }
                )
            }
        }
        CriterionType.SIZE -> {
            val larger = rules.sizePreference == SizePreference.LARGER
            Evaluation(
                scores = candidates.associate { it.key to if (larger) it.sizeBytes.toDouble() else -it.sizeBytes.toDouble() },
                tolerance = 0.0,
                winCode = if (larger) ReasonCode.KEEP_LARGER else ReasonCode.KEEP_SMALLER,
                loseCode = if (larger) ReasonCode.DEL_SMALLER else ReasonCode.DEL_LARGER
            )
        }
        CriterionType.RESOLUTION -> {
            if (category != FileCategory.IMAGE && category != FileCategory.VIDEO) null
            else if (candidates.any { it.pixelCount == null }) MISSING
            else Evaluation(
                scores = candidates.associate { it.key to it.pixelCount!!.toDouble() },
                tolerance = 0.0,
                winCode = ReasonCode.KEEP_HIGHER_RES,
                loseCode = ReasonCode.DEL_LOWER_RES
            )
        }
        CriterionType.FOLDERS -> {
            val scores = candidates.associate {
                it.key to FolderPriority.score(it.relativeDir, rules.preferredFolders, rules.demotedFolders).toDouble()
            }
            Evaluation(
                scores = scores,
                tolerance = 0.0,
                winCode = ReasonCode.KEEP_FOLDER_PRIORITY,
                loseCode = ReasonCode.DEL_FOLDER_PRIORITY,
                // Poraženi: vlastita mapa datoteke.
                args = candidates.associate { f -> f.key to f.relativeDir },
                // Pobjednik: naziv povlaštene mape, ili null ako je pobijedio samo zato što su ostale podređene.
                winArgs = candidates.associate { f ->
                    val pi = FolderPriority.matchIndex(f.relativeDir, rules.preferredFolders)
                    f.key to if (scores.getValue(f.key) > 0 && pi >= 0) rules.preferredFolders[pi] else null
                }
            )
        }
    }
}
