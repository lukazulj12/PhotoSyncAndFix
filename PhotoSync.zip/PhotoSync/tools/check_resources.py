# Provjera lokalizacije: svi korišteni ključevi postoje u oba jezika, formati (%1$s…) se podudaraju,
# XML je ispravan, nema nekorištenih tekstova. Pokretanje: python3 tools/check_resources.py
import re, sys, os, glob
import xml.etree.ElementTree as ET
root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
def load(path):
    return {e.get("name"): (e.text or "") for e in ET.parse(path).getroot().findall("string")}
en = load(os.path.join(root, "app/src/main/res/values/strings.xml"))
hr = load(os.path.join(root, "app/src/main/res/values-hr/strings.xml"))
used = set()
for f in glob.glob(os.path.join(root, "app/src/main/java/**/*.kt"), recursive=True):
    used |= set(re.findall(r"R\.string\.([a-z_0-9]+)", open(f, encoding="utf-8").read()))
for f in glob.glob(os.path.join(root, "app/src/main/**/*.xml"), recursive=True):
    used |= set(re.findall(r"@string/([a-z_0-9]+)", open(f, encoding="utf-8").read()))
errors = []
for k in sorted(used):
    if k not in en: errors.append(f"nedostaje EN: {k}")
    if k not in hr and k != "app_name": errors.append(f"nedostaje HR: {k}")
spec = re.compile(r"%(\d+\$)?[sdf%]")
for k in en:
    if k in hr and sorted(spec.findall(en[k])) != sorted(spec.findall(hr[k])):
        errors.append(f"različiti formati: {k}")
    if re.search(r"(?<!%)%(?![0-9]+\$[sdf]|%)", en[k] + hr.get(k, "")):
        errors.append(f"neispravan % u: {k}")
unused = sorted(set(en) - used)
print(f"EN: {len(en)}  HR: {len(hr)}  korišteno: {len(used)}  nekorišteno: {unused}")
if errors:
    print("\n".join(errors)); sys.exit(1)
print("OK – lokalizacija je potpuna i dosljedna.")
