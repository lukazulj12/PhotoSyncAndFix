# PhotoSync&fix

Android aplikacija s tri dijela, koje biraš na **donjoj traci**:

1. **Duplikati** – pronalaženje i sigurno uklanjanje dupliciranih datoteka
2. **Prijenos** – slanje/primanje datoteka između dva mobitela preko žarišne točke (hotspota) ili Wi-Fi-ja
3. **Datumi** – ispravak datuma fotografija i videozapisa prema datumu u nazivu

Sve radi lokalno – bez registracije, oglasa i slanja podataka na internet.

> **Stanje provjere:** jezgra (`core`) je kompajlirana i testirana – 64 testa prolaze, uključujući stvarni prijenos preko TCP veza,
> ponovno slanje neuspjelih stavki, test brzine i automatsko pronalaženje primatelja (vidi `TEST_RESULTS.md`). Android dio (`app`) gradi se na
> GitHubu; u okruženju u kojem je pisan Android SDK nije bio dostupan, pa je provjerena samo sintaksa. Ako izgradnja javi pogrešku,
> pošaljite zapis pogreške.

## Sadržaj
1. Izgradnja APK-a na GitHubu
2. Inačice `full` i `play`
3. Instalacija na mobitel
4. Duplikati
5. Prijenos između mobitela
6. Ispravak datuma po nazivu
7. **Objava na Google Play – korak po korak**
8. Tekstovi za Google Play i ASO
9. Dopuštenja
10. Arhitektura
11. Poznata ograničenja
12. Promjena naziva aplikacije

---

## 1. Izgradnja APK-a na GitHubu (bez Android Studija)

1. GitHub → repozitorij → **Add file → Upload files** → povucite sadržaj raspakirane mape (ili sam zip) → **Commit changes**.
   Prije toga obrišite stari zip/stare datoteke iz repozitorija.
2. Workflow `.github/workflows/build-apk.yml` pokreće se sam. Ako u repozitoriju postoji i stari `main.yml`, obrišite ga.
3. **Actions** → zadnji prolaz → zelena kvačica → pod **Artifacts** preuzmite **PhotoSync-apk** (`app-full-debug.apk`).

Android Studio (alternativa): *File → Open* → *Build → Build APK(s)*, ili `./gradlew :app:assembleFullDebug`.

## 2. Inačice

| | **full** (APK na vlastiti mobitel) | **play** (Google Play) |
|---|---|---|
| Duplikati, prijenos, ispravak datuma | ✅ | ✅ |
| „Pristup svim datotekama” (cijela pohrana, sve vrste u iste mape, datum izmjene datoteke) | ✅ neobavezno | ❌ |
| Instalacija primljenih aplikacija | ✅ | ❌ (APK-ovi se spremaju u Download/PhotoSync/Aplikacije) |
| Gumb i banner „Počasti developera kavom” | ✅ | ❌ (vidi 7.12) |

## 3. Instalacija na mobitel
Kopirajte APK na mobitel, otvorite ga i dopustite „Instaliraj nepoznate aplikacije”. Potreban je **Android 11 ili noviji**.
ID aplikacije je novi (`hr.zulj.photosync`), pa se PhotoSync&fix instalira kao nova aplikacija – stari DuoMove možete deinstalirati.
Instalirajte istu verziju na **oba** mobitela (protokol prijenosa promijenjen je u ovoj verziji).

## 4. Duplikati
Skeniranje, grupe (identične / ista fotografija / slične / isti naziv), pravila odabira (prioritet mapa → datum → veličina → rezolucija),
vremenski interval, rad u pozadini, pregled, potvrda, izvještaj i oporavak.

**Postavka „Traži slične fotografije”:** kad je isključena, traže se **samo potpuno identične datoteke** (SHA-256) – perceptualni
hash se ne računa, pa nema ni grupa „ista fotografija u drugoj veličini” ni „slične fotografije” i ništa se takvo ne označava
automatski. (Ispravljena pogreška: prije su se vizualni duplikati tražili i označavali i uz isključenu postavku.)

## 5. Prijenos između mobitela

### 5.1 Spajanje – žarišna točka jednog od mobitela (svejedno kojeg)
1. Na **jednom** mobitelu uključite **žarišnu točku (hotspot)**. Preporuka: na **novom**, jer je u njemu obično SIM kartica –
   ali radi i obrnuto. Aplikacija ima gumb *Postavke žarišne točke*.
2. **Drugi** mobitel spojite na tu žarišnu točku (Wi-Fi). Gumb *Postavke Wi-Fi-ja*. Ako mobitel javi „mreža nema internet”, odaberite da ostane spojen.
3. Alternativa: oba mobitela na **istom kućnom Wi-Fi-ju** – žarišna točka tada nije potrebna.

Na zaslonu Prijenos kartica stanja pokazuje je li mobitel spreman (*žarišna točka uključena* / *spojen na Wi-Fi*) i njegovu IP adresu;
osvježava se svake 2 sekunde.

### 5.2 Postupak
1. **Novi mobitel** → **Primi** → prikazuje se veliki **kod od 4 znamenke** (npr. `4821`) i istaknuta **IP adresa** ovog mobitela.
2. **Stari mobitel** → **Pošalji** → označite vrste (fotografije, videozapisi, audiozapisi, dokumenti, ZIP/RAR/7Z, APK datoteke,
   aplikacije, ostalo) → po želji vremenski interval → **Pronađi datoteke** → odznačite mape koje ne želite → upišite **kod** → **Pošalji**.
3. Stari mobitel **sam pronalazi** novi (UDP upit u lokalnoj mreži; ako ga uređaj blokira, rezervno se provjerava port na adresama
   lokalne podmreže). Ako ni to ne uspije, upišite IP adresu prikazanu na novom mobitelu (*Upiši IP adresu ručno*).
4. Napredak, brzina i preostalo vrijeme prikazuju se na oba mobitela; na kraju izvještaj.

### 5.3 Neuspjele stavke i ponovno slanje
Nakon prijenosa prikazuje se **popis stavki koje nisu prenesene** (naziv, mapa, veličina i razlog: veza prekinuta, datoteka se ne može
pročitati, promijenila se tijekom slanja, greška pri spremanju…). Na starom mobitelu gumb **Pošalji ponovno neuspjele (N)** šalje samo
njih – istom primatelju, istim kodom. Novi mobitel zato **nakon prijenosa i dalje prima** dok se ondje ne dodirne *Gotovo*.

### 5.4 Kamo se spremaju primljene datoteke
- **Opcija „Spremi u mape istog naziva ako postoje”:** fotografija iz `DCIM/Camera` ide u `DCIM/Camera` i na novom mobitelu,
  snimka zaslona u `Pictures/Screenshots` itd. – ako ta mapa na novom mobitelu postoji. Bez „Pristupa svim datotekama” to vrijedi za
  fotografije, videozapise i audiozapise (Android drugim aplikacijama ne pokazuje mape s dokumentima).
- **Ostalo (ili sve, kad je opcija isključena)** ide u:
  - **zadanu mapu** s podmapom za svaku vrstu – `PhotoSync/Fotografije`, `Videozapisi`, `Audiozapisi`, `Dokumenti`, `Arhive`, `APK`,
    `Aplikacije`, `Ostalo`:
    - uz „Pristup svim datotekama” (full): `/storage/emulated/0/PhotoSync`
    - inače: `/storage/emulated/0/Download/PhotoSync` (Android dopušta aplikacijama spremanje svih vrsta datoteka samo u Download)
  - ili **ručno odabranu mapu** (*Odaberi drugu mapu…* – sistemski birač mapa), također s podmapama po vrsti.
- *Zadrži nazive izvornih mapa* dodaje podmapu izvorne mape (npr. `PhotoSync/Fotografije/Camera`).
- *Preskoči datoteke koje već postoje* – iste veličine i naziva na odredištu.
Točna putanja prikazana je na zaslonu Prijenos (prije, tijekom i nakon primanja).

### 5.5 Brzina, test brzine, zaslon i mobilni podaci
**Kako aplikacija postiže brzinu:**
- 4 paralelne TCP veze; najveće datoteke idu prve.
- **Bez čekanja potvrde za svaku datoteku:** pošiljatelj šalje datoteke jednu za drugom, a potvrde stižu usporedno
  (najviše 16 nepotvrđenih po vezi). Primatelj sprema datoteku (MediaStore, upis datuma) u pozadinskoj dretvi dok već prima
  sljedeću – spremanje i kašnjenje mreže više ne zaustavljaju tok podataka.
- Međuspremnike veza podešava sustav automatski (ručno zadana veličina na Androidu isključuje automatsko prilagođavanje).
- **Wi-Fi lock niske latencije** (`WIFI_MODE_FULL_LOW_LATENCY`, Android 10+) i visokih performansi drže Wi-Fi izvan štednog
  načina cijelo vrijeme prijenosa – na oba mobitela, neovisno o opciji rada u pozadini.

**Test brzine** (Pošalji → odmah ispod koda): 8 sekundi šalje podatke novom mobitelu bez čitanja i spremanja datoteka i
pokazuje čistu brzinu mreže (MB/s i Mbit/s), ocjenu, procjenu trajanja za odabrane datoteke i savjete. Ako je test brz, a pravi
prijenos spor, usko grlo je čitanje/spremanje (npr. puno malih datoteka); ako je i test spor, usko grlo je Wi-Fi.

**Pojas Wi-Fi-ja:** mobitel spojen na žarišnu točku prikazuje pojas i brzinu veze (npr. „Wi-Fi veza: 5 GHz · 866 Mbit/s”).
Na 2,4 GHz realno je 2–6 MB/s, na 5 GHz 10–40 MB/s.
- Samsung: Žarišna točka → Konfiguriraj → **Pojas** → 5 GHz preferirano; u naprednim postavkama isključite **Štednju energije**.
- Xiaomi: Postavi prijenosnu žarišnu točku → **AP pojas** → 5 GHz.
- Google Pixel: **isključite „Proširi kompatibilnost”** (uključena drži žarišnu točku na 2,4 GHz).
- Ako opcije nema: mobitel možda ne podržava žarišnu točku na 5 GHz – uključite žarišnu točku na **drugom** mobitelu ili spojite
  oba na kućni ruter na 5 GHz.
- Mobitel sa žarišnom točkom ne smije biti spojen na drugu Wi-Fi mrežu (žarišna točka tada mora koristiti njen kanal).

**Zaslon:** *Nastavi u pozadini* (usluga s obaviješću, wake lock) i *Drži zaslon upaljenim* – uključite na oba mobitela. Wi-Fi lock
niske latencije djeluje samo dok je aplikacija na zaslonu, pa je upaljen zaslon i najbrži. Ako proizvođač gasi aplikaciju:
Postavke → Aplikacije → PhotoSync&fix → Baterija → Bez ograničenja.

**Mobilni podaci:** sam prijenos ne troši mobilne podatke (ide lokalno). Mobitel spojen na žarišnu točku može za svoje druge
aplikacije (npr. sigurnosnu kopiju fotografija) trošiti podatke mobitela sa žarišnom točkom – po potrebi ih privremeno isključite.

### 5.6 Sigurnost
- Kod od 4 znamenke nikad se ne šalje mrežom; iz njega se izvodi ključ za provjeru (HMAC-SHA256 izazov–odgovor na svakoj vezi).
- Nakon **10 pogrešnih pokušaja** primatelj se zaustavlja (pogađanje 10 000 kombinacija nije moguće); novi *Primi* daje novi kod.
- Odgovor na upit „tko prima?” ne ovisi o kodu, pa se kod iz njega ne može doznati.
- Zaštita od „../” putanja: datoteke se uvijek spremaju unutar dopuštenih mapa.
- Prijenos nije šifriran (radi brzine); mreža žarišne točke zaštićena je njenom WPA2/WPA3 lozinkom.

### 5.7 Izvorni datumi
Zadržava se datum izmjene datoteke (uvijek uz pristup svim datotekama, inače kad Android dopusti) i datum snimanja. Fotografijama
(JPG/PNG/WEBP) i videozapisima (MP4/MOV/3GP) koji nemaju vlastiti datum snimanja (npr. WhatsApp) izvorni datum upisuje se u datoteku,
pa ih galerija na novom mobitelu prikazuje pod pravim datumom.

### 5.8 Aplikacije
Šalju se APK datoteke instaliranih aplikacija (i dijelovi „split APK”). Podaci aplikacija i prijave ne mogu se prenijeti (Androidova
zaštita). U inačici full primljene aplikacije instalirate gumbom *Instaliraj* (Android traži potvrdu za svaku).

### 5.9 Može li Bluetooth uz Wi-Fi ubrzati prijenos?
Ne, u praksi ne:
- Bluetooth na mobitelima stvarno prenosi oko **0,1–0,3 MB/s**, a Wi-Fi veza između mobitela **10–40 MB/s** – Bluetooth bi dodao
  manje od 1 % brzine.
- Na većini mobitela Bluetooth i Wi-Fi (2,4 GHz) dijele isti radio-čip i antenu, pa istovremeni Bluetooth prijenos može **usporiti** Wi-Fi.
- Bluetooth bi tražio dodatna dopuštenja (uređaji u blizini) i uparivanje, a donio bi samo složenost.
Najviše pomaže: žarišna točka na **5 GHz**, mobitele držati blizu, oba punjača uključena i ugašen štedni način rada.

## 6. Ispravak datuma po nazivu

Fotografije i videozapisi kopirani na novi mobitel često dobiju datum kopiranja, pa se u galeriji pojave pod „danas”.
PhotoSync&fix uspoređuje datum datoteke s datumom u nazivu i ispravlja ga.

1. **Datumi** → odaberite **fotografije, videozapise ili oboje**, po želji **mape** (zadano sve) i **vremenski interval** (primjenjuje se na datum iz naziva ili na trenutačni datum).
2. **Analiziraj** → popis datoteka čiji datum ne odgovara nazivu: trenutačni datum, novi datum, sličica, oznaka za odabir.
   Datoteke bez datuma u nazivu se **preskaču** (navedeno je koliko ih je). Datum pojedine datoteke možete ručno promijeniti (ikona kalendara).
3. **Ispravi odabrane** → potvrda → izvještaj. Obrada ide u serijama od 400 datoteka (i za nekoliko tisuća datoteka), zaslon ostaje upaljen.
   Bez pristupa svim datotekama Android traži odobrenje izmjene za svaku seriju; uz pristup svim datotekama (APK inačica) ne traži.

**Prepoznati oblici** (primjeri): `IMG-20261028-WA0014.jpg`, `VID_20250705_105923_016.mp4`, `IMG_20230115_120000.jpg`,
`PXL_20241231_235959123.jpg`, `Screenshot_2025-07-05-10-59-23.png`, `scan_15-01-2023.pdf`, `15.01.2023.jpg`, `FB_IMG_1700000000000.jpg` (Unix vrijeme).
Prihvaćaju se samo stvarni datumi od 1990. do danas.

**DDMM ili MMDD:** ako je moguće samo jedno tumačenje (npr. `28102026` – nema 28. mjeseca), koristi se ono. Kad su moguća oba
(npr. `05072025`), odlučuje postavka: *Uobičajeno* (GGGGMMDD i DDMMGGGG), *Mjesec prije dana*, *Dan prije mjeseca* ili *Preskoči*.
Takve datoteke označene su upozorenjem „dan i mjesec mogli bi biti zamijenjeni”.

**Ručni oblici naziva:** npr. `IMG-yyyyMMdd-WA*`, `Snimka yy-MM-dd HH.mm*`, `*_ddMMyyyy*`. Oznake: `yyyy` godina, `yy` dvoznamenkasta godina,
`MM` mjesec, `dd` dan, `HH` sat, `mm` minute, `ss` sekunde, `*` bilo što, `?` jedan znak, `#` jedna znamenka. Uz unos postoji provjera na primjeru naziva.

**Što se mijenja:** datum snimanja – EXIF za JPG/PNG/WEBP, datum stvaranja u MP4/MOV/3GP (mijenjaju se samo polja datuma, sadržaj ostaje isti);
datum izmjene datoteke – samo uz „Pristup svim datotekama”. Ako naziv nema vrijeme, zadržava se dosadašnje vrijeme u danu.
HEIC, MKV, AVI i sl. ne mogu spremiti datum na ovaj način (uz pristup svim datotekama mijenja im se datum izmjene).
Napomena: stvarni „datum stvaranja” datoteke na Androidu ne može se mijenjati; galerije koriste datum snimanja i datum izmjene.

## 7. Objava na Google Play – korak po korak

### 7.1 Prije prve objave
- **Naziv:** „PhotoSync – Transfer Photos” (touchbyte GmbH) već postoji na Google Playu i radi sličan posao (prijenos fotografija).
  Pravila o lažnom predstavljanju zabranjuju nazive koji korisnike mogu navesti na pomisao da je aplikacija povezana s drugom, a
  „PhotoSync” je vjerojatno i zaštićeni znak tog developera. **„PhotoSync&fix” zato nosi rizik odbijanja ili kasnijeg uklanjanja.**
  Sigurnije je odabrati naziv koji ne sadrži „PhotoSync” (vidi 12. – promjena traje nekoliko minuta).
- **ID aplikacije:** `hr.zulj.photosync` (`app/build.gradle.kts` → `applicationId`). Nakon prve objave **ne može se promijeniti**
  (ostaje i ako kasnije promijenite naziv; korisnici ga vide samo u poveznici). Ako mijenjate naziv prije objave, po želji promijenite i ID.
- **Testiranje:** novi osobni računi (otvoreni nakon 13. 11. 2023.) prije produkcije moraju provesti **zatvoreno testiranje s najmanje
  12 testera tijekom 14 dana** zaredom. Provjerite na nadzornoj ploči Play Consolea.
- **Ciljana verzija:** `targetSdk = 36` (Android 16), što Google Play traži od 31. 8. 2026.
- **Verzija:** `versionCode = 1`, `versionName = "1.0.0"`; svako sljedeće slanje traži veći `versionCode`.

### 7.2 Ključ za potpisivanje (jednom)
1. `keytool -genkeypair -v -keystore upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000`
   (lozinku i `upload.jks` čuvajte na sigurnom; nikad u repozitorij – `.gitignore` ih već isključuje).
2. Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("upload.jks")) | Set-Content upload.b64`
3. GitHub → **Settings → Secrets and variables → Actions → New repository secret**:
   `SIGNING_KEYSTORE_BASE64` (sadržaj `upload.b64`), `SIGNING_STORE_PASSWORD`, `SIGNING_KEY_ALIAS` (`upload`), `SIGNING_KEY_PASSWORD`.
4. Actions → „Izgradi APK” → **Run workflow** → pod Artifacts: **PhotoSync-google-play-aab** (`app-play-release.aab`).

Lokalno: datoteka `keystore.properties` u korijenu (`storeFile`, `storePassword`, `keyAlias`, `keyPassword`) i `./gradlew :app:bundlePlayRelease`.

### 7.3 Pravila privatnosti
Tekst je u `PRIVACY_POLICY.md` (HR i EN). Objavite ga kao javnu stranicu (npr. javni gist na gist.github.com, GitHub Pages ili
Google Sites) i kopirajte poveznicu.

### 7.4 Izrada aplikacije
Play Console → **Izradi aplikaciju** → naziv (vidi 7.1), zadani jezik *hrvatski*, *Aplikacija*, *Besplatno*, prihvatite izjave.

### 7.5 Sadržaj aplikacije (Politika → Sadržaj aplikacije)
| Odjeljak | Odgovor |
|---|---|
| Pravila o privatnosti | poveznica iz 7.3 |
| Pristup aplikaciji | sve funkcije dostupne bez prijave |
| Oglasi | ne |
| Ocjena sadržaja | upitnik – kategorija *Uslužni program, produktivnost, komunikacija ili ostalo*, sve „Ne” |
| Ciljana publika | 18+ (ili 13+), nije namijenjena djeci |
| **Sigurnost podataka** | „Prikuplja li ili dijeli aplikacija korisničke podatke?” → **Ne**. Obrazloženje: sve se obrađuje na uređaju; prijenos ide izravno na drugi uređaj korisnika na njegov zahtjev, bez developera i trećih strana (Google prijenos na korisnikov zahtjev između njegovih uređaja ne smatra „prikupljanjem” ni „dijeljenjem”). |
| Financijske značajke, zdravlje, vladine aplikacije, vijesti | ne |

### 7.6 Deklaracija za fotografije i videozapise (READ_MEDIA_IMAGES / READ_MEDIA_VIDEO)
**Sadržaj aplikacije → Dopuštenja za fotografije i videozapise**. Prijedlog obrazloženja:
> *PhotoSync&fix's core features require broad access to the user's photos and videos: (1) transferring the user's chosen photos and
> videos (often the whole library, filtered by date range and folder) to their new phone over the local network, (2) fixing the date taken
> of photos/videos whose date does not match the date in their file name, and (3) finding exact duplicates across the whole library.
> The Android photo picker would require the user to select thousands of files manually. All processing is on-device; nothing is uploaded.*

### 7.7 Usluga u prvom planu (Foreground service)
**Sadržaj aplikacije → Usluge u prvom planu** → vrsta *Data sync*:
> *User-initiated transfer of the user's files to their other device over the local network, and user-initiated file scanning.
> Progress is shown in a notification and the user can cancel at any time.*
Po potrebi priložite kratki video (snimka zaslona) pokretanja prijenosa i skeniranja.

### 7.8 Lokacija i uređaji u blizini – više nisu potrebni
Wi-Fi Direct je zamijenjen žarišnom točkom / Wi-Fi-jem, pa aplikacija **više ne traži** `NEARBY_WIFI_DEVICES` ni dopuštenja za
lokaciju. U Play Consoleu zato nema obrasca za lokaciju. Koriste se samo `INTERNET`, `ACCESS_NETWORK_STATE`, `ACCESS_WIFI_STATE`
i `CHANGE_WIFI_MULTICAST_STATE` (za koje se ne podnosi deklaracija).

### 7.9 Glavni unos trgovine
Svi tekstovi (naziv, kratki i puni opis na hrvatskom i engleskom, kategorija, oznake, natpisi za snimke zaslona): **`store/listing.md`**.
Ikona 512×512: `store/icon-512.png`. Istaknuta grafika 1024×500: `store/feature-graphic-1024x500.png`.
Snimke zaslona: najmanje 2 (preporuka 4–8) – sva tri dijela aplikacije (snimka: tipka za uključivanje + stišavanje).

### 7.10 Izdanje
1. **Testiranje → Zatvoreno testiranje** → popis testera (e-pošte; najmanje 12) → *Izradi novo izdanje* → prihvatite **Play App Signing**
   → uploadajte `app-play-release.aab` → bilješke o izdanju (prijedlog u `store/listing.md`) → *Pregledaj* → *Pokreni*.
   Testerima pošaljite poveznicu za sudjelovanje; moraju ostati prijavljeni 14 dana.
2. Nakon toga: **Nadzorna ploča → Zatraži pristup produkciji** (kratki upitnik o testiranju).
3. **Produkcija → Izradi novo izdanje** (ili *Promoviraj izdanje*) → države → slanje na pregled (obično nekoliko dana).
4. **Ažuriranja:** u `app/build.gradle.kts` povećajte `versionCode` (2, 3, …) i `versionName`, ponovno izgradite AAB i uploadajte.
5. Ako Google odbije: u e-poruci piše razlog (dopuštenje, naziv, opis); doradite i pošaljite ponovno.

### 7.11 Nakon objave (ASO)
- *Statistika → Akvizicija iz trgovine*: pratite pretraživanja kojima ljudi dolaze i prilagodite kratki opis.
- Odgovarajte na recenzije; ocjena utječe na rang.
- Dodajte prijevode unosa (npr. njemački, talijanski, slovenski) – svaki jezik je zaseban unos za pretraživanje.

### 7.12 Donacije
Pravila plaćanja Google Playa dopuštaju vanjske poveznice za plaćanje (PayPal) samo za donacije oslobođene poreza (dobrotvorne udruge).
Zato je u inačici `play` gumb za donaciju isključen (`SHOW_DONATE = false` u `app/build.gradle.kts`). U inačici `full` gumb i banner
pojavljuju se nakon skeniranja, nakon uspješnog prijenosa (na oba mobitela) i nakon ispravljanja datuma. Siguran način na Playu je
donacija preko Google Play naplate (jednokratna kupnja „Kava”), koja se može dodati kasnije.

## 8. Tekstovi za Google Play i ASO
Sve je u **`store/listing.md`**:
- **Naziv** s ključnom riječi (HR: `PhotoSync&fix – prijenos slika`, EN: `PhotoSync&fix: Phone Transfer`) – naziv najviše utječe na pretraživanje.
- **Kratki opis** (≤ 80 znakova) i **puni opis** (≤ 4000) s prirodno upotrijebljenim izrazima koje ljudi traže (prijenos fotografija na
  novi mobitel, krivi datum fotografija, WhatsApp datum, brisanje duplikata, bez interneta…).
- Popis ključnih riječi, kategorija, oznake, prijedlog snimaka zaslona s natpisima, bilješke o izdanju.

## 9. Dopuštenja

| Dopuštenje | Svrha |
|---|---|
| `READ_MEDIA_IMAGES/VIDEO/AUDIO` (13+), `READ_EXTERNAL_STORAGE` (11–12), `READ_MEDIA_VISUAL_USER_SELECTED` (14+) | Duplikati, ispravak datuma, slanje, spremanje u iste mape |
| `ACCESS_MEDIA_LOCATION` | Izvorni bajtovi fotografija (usporedba, prijenos s EXIF lokacijom) |
| `INTERNET`, `ACCESS_NETWORK_STATE`, `ACCESS_WIFI_STATE` | Lokalna veza između mobitela (ne internet) |
| `CHANGE_WIFI_MULTICAST_STATE` | Primanje upita „tko prima?” (UDP broadcast) i s ugašenim zaslonom |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_DATA_SYNC`, `WAKE_LOCK`, `POST_NOTIFICATIONS` | Rad u pozadini s obaviješću |
| `<queries>` za aplikacije s ikonom | Popis aplikacija za prijenos (bez `QUERY_ALL_PACKAGES`) |
| `MANAGE_EXTERNAL_STORAGE`, `REQUEST_INSTALL_PACKAGES` | **Samo full**: cijela pohrana; instalacija primljenih aplikacija |

## 10. Arhitektura
```
core/ (čisti Kotlin, JVM testovi)
  dates/     NameDateParser (DDMM/MMDD, vrijeme, Unix vrijeme), NamePattern (ručni oblici), DateFixPlanner
  media/     Mp4Dates – izmjena datuma u mvhd/tkhd/mdhd na mjestu
  transfer/  TransferSender / TransferReceiver – kontrolna veza + 4 podatkovne, HMAC kod (4 znamenke, najviše 10 pokušaja),
             provjera prostora, preskakanje postojećih; Discovery – UDP pronalaženje primatelja (port 47655)
  logic/, scan/, hash/  – duplikati
app/
  datefix/   čitanje iz MediaStorea, upis EXIF/MP4/datuma izmjene, MediaStore.createWriteRequest
  transfer/  LocalNet (stanje mreže, soketi vezani uz Wi-Fi, rezervna provjera porta, prečaci u postavke),
             TransferScanner, AndroidTransferSource/Sink (iste mape / zadana / ručno odabrana mapa),
             TransferManager (ponovno slanje neuspjelih), TransferService, ApkInstaller
  ui/        donja traka (Duplikati / Prijenos / Datumi), zasloni, HR/EN lokalizacija
```
Napomena: Android usmjerava promet prema mreži bez interneta (žarišna točka) preko mobilnih podataka ako soket nije vezan uz Wi-Fi
mrežu; zato se upiti, odgovori i veze prema adresama u Wi-Fi podmreži šalju kroz soket vezan uz tu mrežu (`Network.bindSocket`).

## 11. Poznata ograničenja
1. Android 11+.
2. Neki mobiteli (rijetko) u žarišnoj točki izoliraju klijente jedne od drugih – tada uključite žarišnu točku na drugom mobitelu ili
   koristite kućni Wi-Fi.
3. Inačica play bez dodanih mapa ne vidi dokumente drugih aplikacija; pri primanju ne može vratiti izvorni datum izmjene
   (datum snimanja u EXIF-u/videozapisu ostaje – za ostalo pomaže dio *Datumi*); „iste mape” vrijede samo za medije.
4. Aplikacije se prenose bez podataka i prijava; instalacija iz aplikacije samo u inačici full.
5. Ispravak datuma: HEIC/MKV/AVI bez upisa datuma snimanja; datum izmjene samo uz pristup svim datotekama; stvarni datum stvaranja nije promjenjiv.
6. Pixel (PXL_…) u nazivu zapisuje UTC vrijeme – zato se zadano uspoređuje samo datum, ne i vrijeme.
7. Neki proizvođači gase aplikacije u pozadini – uključite „Drži zaslon upaljenim” i neograničenu potrošnju baterije.
8. Android 15+: usluge vrste dataSync ograničene su na 6 sati dnevno.
9. Brisanje medija i (bez pristupa svim datotekama) izmjena datuma uvijek prolaze kroz Androidov sistemski dijalog.
10. Oba mobitela moraju imati istu verziju aplikacije (protokol je promijenjen – starija verzija i ova ne mogu razmjenjivati datoteke).

## 12. Promjena naziva aplikacije
Naziv je na jednom mjestu za aplikaciju i na jednom za mapu:
1. `tools/strings_source.py` → `"app_name": ("Novi naziv", "Novi naziv")`; u istoj datoteci zamijenite „PhotoSync&fix” u tekstovima
   (Pretraži i zamijeni), zatim pokrenite `python3 tools/strings_source.py`.
2. Mapa za primljene datoteke: `app/build.gradle.kts` → `APP_FOLDER` (npr. `"NoviNaziv"`).
3. Po želji `applicationId` (samo prije prve objave!) i tekstovi u `store/listing.md`, `PRIVACY_POLICY.md`, grafika
   `store/feature-graphic-1024x500.png`.
