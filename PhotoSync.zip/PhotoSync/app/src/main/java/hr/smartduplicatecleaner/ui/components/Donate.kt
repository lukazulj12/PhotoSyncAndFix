package hr.smartduplicatecleaner.ui.components

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocalCafe
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import hr.smartduplicatecleaner.BuildConfig
import hr.smartduplicatecleaner.R

/**
 * Donacija ("Počasti developera kavom"). Poveznica je u app/build.gradle.kts (DONATE_URL),
 * a prikaz se uključuje/isključuje po inačici (SHOW_DONATE).
 */
fun openDonate(context: Context) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(BuildConfig.DONATE_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: ActivityNotFoundException) {
        // Nema preglednika – ništa se ne događa.
    }
}

@Composable
fun DonateButton(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    OutlinedButton(onClick = { openDonate(context) }, modifier = modifier) {
        Icon(Icons.Filled.LocalCafe, null)
        Spacer(Modifier.size(8.dp))
        Text(stringResource(R.string.donate_button))
    }
}

/** Mali okrugli gumb sa strane glavnog zaslona. */
@Composable
fun DonateFab(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    SmallFloatingActionButton(
        onClick = { openDonate(context) },
        modifier = modifier,
        containerColor = MaterialTheme.colorScheme.tertiaryContainer
    ) {
        Icon(Icons.Filled.LocalCafe, stringResource(R.string.donate_button))
    }
}

/**
 * Mali banner nakon završenog skeniranja, uspješnog prijenosa ili ispravljanja datuma. Ne blokira ništa
 * (nije dijalog), može se zatvoriti tipkom X i sam nestaje nakon nekoliko sekundi.
 */
@Composable
fun DonateBanner(text: String, onClose: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Row(Modifier.padding(start = 12.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.LocalCafe, null, tint = MaterialTheme.colorScheme.onTertiaryContainer)
            Text(
                text,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onTertiaryContainer,
                modifier = Modifier.weight(1f).padding(horizontal = 10.dp)
            )
            FilledTonalButton(onClick = { openDonate(context); onClose() }) { Text(stringResource(R.string.donate_short)) }
            IconButton(onClick = onClose) { Icon(Icons.Filled.Close, stringResource(R.string.close)) }
        }
    }
}
