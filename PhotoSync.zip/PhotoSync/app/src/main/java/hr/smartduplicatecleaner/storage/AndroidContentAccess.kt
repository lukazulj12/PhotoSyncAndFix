package hr.smartduplicatecleaner.storage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import hr.smartduplicatecleaner.core.hash.GrayImage
import hr.smartduplicatecleaner.core.logic.ExifDateParser
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.model.SourceType
import hr.smartduplicatecleaner.core.scan.ContentAccess
import hr.smartduplicatecleaner.core.scan.ImageAnalysis
import hr.smartduplicatecleaner.core.scan.ImageMetadata
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.InputStream
import java.time.ZoneId

/**
 * Čitanje sadržaja datoteka na Androidu. Slike se dekodiraju umanjeno (inSampleSize),
 * pa se u memoriju nikad ne učitava fotografija pune rezolucije.
 */
class AndroidContentAccess(private val context: Context) : ContentAccess {

    private val resolver get() = context.contentResolver

    override fun open(file: ScannedFile): InputStream = openRaw(file, requireOriginal = true)

    private fun openRaw(file: ScannedFile, requireOriginal: Boolean): InputStream {
        if (file.source == SourceType.FILE_SYSTEM) {
            return FileInputStream(File(file.absolutePath ?: throw FileNotFoundException(file.uri)))
        }
        var uri = Uri.parse(file.uri)
        // Bez setRequireOriginal Android redigira GPS podatke u EXIF-u, pa bi se dvije fotografije
        // koje se razlikuju samo po lokaciji mogle pogrešno proglasiti identičnima.
        if (requireOriginal && file.source == SourceType.MEDIA_STORE &&
            file.category != FileCategory.AUDIO && StorageAccess.hasMediaLocation(context)
        ) {
            uri = MediaStore.setRequireOriginal(uri)
        }
        return try {
            resolver.openInputStream(uri) ?: throw FileNotFoundException(file.uri)
        } catch (e: UnsupportedOperationException) {
            resolver.openInputStream(Uri.parse(file.uri)) ?: throw FileNotFoundException(file.uri)
        }
    }

    override fun analyzeImage(file: ScannedFile): ImageAnalysis? {
        // 1) Samo dimenzije.
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        openRaw(file, requireOriginal = false).use { BitmapFactory.decodeStream(it, null, bounds) }
        val w = bounds.outWidth
        val h = bounds.outHeight
        if (w <= 0 || h <= 0) return null

        // 2) Umanjeno dekodiranje – najmanja stranica oko 128–256 px je dovoljna za perceptualni hash.
        var sample = 1
        while (minOf(w, h) / (sample * 2) >= TARGET_MIN_SIDE) sample *= 2
        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val bitmap = openRaw(file, requireOriginal = false).use { BitmapFactory.decodeStream(it, null, options) } ?: return null
        try {
            val bw = bitmap.width
            val bh = bitmap.height
            val pixels = IntArray(bw * bh)
            bitmap.getPixels(pixels, 0, bw, 0, 0, bw, bh)
            val orientation = readOrientation(file)
            val gray = GrayImage.fromArgb(bw, bh, pixels).applyExifOrientation(orientation)
            val rotated = orientation in 5..8
            return ImageAnalysis(gray, if (rotated) h else w, if (rotated) w else h)
        } finally {
            bitmap.recycle()
        }
    }

    private fun readOrientation(file: ScannedFile): Int = try {
        openRaw(file, requireOriginal = false).use { stream ->
            ExifInterface(stream).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        }
    } catch (e: Exception) {
        ExifInterface.ORIENTATION_NORMAL
    }

    override fun readMetadata(file: ScannedFile): ImageMetadata? = try {
        openRaw(file, requireOriginal = false).use { stream ->
            val exif = ExifInterface(stream)
            val date = ExifDateParser.parse(
                exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)
                    ?: exif.getAttribute(ExifInterface.TAG_DATETIME_DIGITIZED),
                exif.getAttribute(ExifInterface.TAG_OFFSET_TIME_ORIGINAL),
                ZoneId.systemDefault(),
                System.currentTimeMillis()
            )
            val w = exif.getAttributeInt(ExifInterface.TAG_PIXEL_X_DIMENSION, 0)
                .takeIf { it > 0 } ?: exif.getAttributeInt(ExifInterface.TAG_IMAGE_WIDTH, 0).takeIf { it > 0 }
            val h = exif.getAttributeInt(ExifInterface.TAG_PIXEL_Y_DIMENSION, 0)
                .takeIf { it > 0 } ?: exif.getAttributeInt(ExifInterface.TAG_IMAGE_LENGTH, 0).takeIf { it > 0 }
            ImageMetadata(date, w, h)
        }
    } catch (e: Exception) {
        null
    }

    companion object {
        private const val TARGET_MIN_SIDE = 128
    }
}
