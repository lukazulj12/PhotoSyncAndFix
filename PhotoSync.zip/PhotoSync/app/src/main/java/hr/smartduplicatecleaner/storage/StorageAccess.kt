package hr.smartduplicatecleaner.storage

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.DocumentsContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.util.Locale

/** Stanje dopuštenja za medijske datoteke. */
enum class MediaAccess { FULL, PARTIAL, NONE }

/** Pomoćne funkcije za dopuštenja, volumene i kanonske ključeve datoteka. */
object StorageAccess {

    /** Naziv mape za oporavak (izuzeta iz skeniranja). */
    const val RECOVERY_DIR = "PhotoSync_Oporavak"

    /** Dopuštenja koja se traže za medije, ovisno o verziji Androida. */
    fun mediaPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val list = mutableListOf(
                Manifest.permission.READ_MEDIA_IMAGES,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.ACCESS_MEDIA_LOCATION
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                list += Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
            }
            list.toTypedArray()
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.ACCESS_MEDIA_LOCATION)
        }

    private fun granted(context: Context, permission: String) =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    fun imagesAccess(context: Context): MediaAccess = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && granted(context, Manifest.permission.READ_MEDIA_IMAGES) -> MediaAccess.FULL
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU && granted(context, Manifest.permission.READ_EXTERNAL_STORAGE) -> MediaAccess.FULL
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE &&
            granted(context, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) -> MediaAccess.PARTIAL
        else -> MediaAccess.NONE
    }

    fun videoAccess(context: Context): MediaAccess = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && granted(context, Manifest.permission.READ_MEDIA_VIDEO) -> MediaAccess.FULL
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU && granted(context, Manifest.permission.READ_EXTERNAL_STORAGE) -> MediaAccess.FULL
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE &&
            granted(context, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) -> MediaAccess.PARTIAL
        else -> MediaAccess.NONE
    }

    fun audioAccess(context: Context): MediaAccess = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && granted(context, Manifest.permission.READ_MEDIA_AUDIO) -> MediaAccess.FULL
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU && granted(context, Manifest.permission.READ_EXTERNAL_STORAGE) -> MediaAccess.FULL
        else -> MediaAccess.NONE
    }

    /** Ukupno stanje: FULL samo ako su odobreni svi medijski tipovi. */
    fun mediaAccess(context: Context): MediaAccess {
        val all = listOf(imagesAccess(context), videoAccess(context), audioAccess(context))
        return when {
            all.all { it == MediaAccess.FULL } -> MediaAccess.FULL
            all.all { it == MediaAccess.NONE } -> MediaAccess.NONE
            else -> MediaAccess.PARTIAL
        }
    }

    fun hasMediaLocation(context: Context) = granted(context, Manifest.permission.ACCESS_MEDIA_LOCATION)

    /** Pristup svim datotekama – samo u inačici "full" (u inačici za Google Play dopuštenje ne postoji). */
    fun hasAllFilesAccess(): Boolean = hr.smartduplicatecleaner.BuildConfig.ALLOW_ALL_FILES && Environment.isExternalStorageManager()

    fun hasNotificationPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU || granted(context, Manifest.permission.POST_NOTIFICATIONS)

    /** Intent za sistemski zaslon "Pristup svim datotekama" za ovu aplikaciju. */
    fun allFilesAccessIntent(context: Context): Intent =
        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + context.packageName))

    fun allFilesAccessFallbackIntent(): Intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)

    fun appSettingsIntent(context: Context): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.packageName))

    /** Kanonski ključ: volumen + relativna putanja, malim slovima (isti za MediaStore, SAF i datotečni sustav). */
    fun canonicalKey(volume: String, relativeDir: String, name: String): String =
        (volume + "/" + normalizeDir(relativeDir) + name).lowercase(Locale.ROOT)

    fun normalizeDir(dir: String): String {
        val t = dir.trim('/')
        return if (t.isEmpty()) "" else "$t/"
    }

    /** MediaStore naziv volumena iz SAF identifikatora ("primary" → "external_primary"). */
    fun volumeFromSafRoot(root: String): String =
        if (root.equals("primary", ignoreCase = true)) "external_primary" else root.lowercase(Locale.ROOT)

    /** Mape koje se nikad ne skeniraju niti brišu: podaci drugih aplikacija i naša mapa za oporavak. */
    fun isProtectedDir(relativeDir: String): Boolean {
        val d = normalizeDir(relativeDir).lowercase(Locale.ROOT)
        return d.startsWith("android/data/") || d.startsWith("android/obb/") ||
            d.startsWith(RECOVERY_DIR.lowercase(Locale.ROOT) + "/") ||
            d.startsWith("smartduplicatecleaner_oporavak/") || d.startsWith("duplicatecleaner_oporavak/") ||
            d.startsWith("duomove_oporavak/")
    }

    /** Čitljiv naziv SAF mape, npr. "primary:Download/Docs" → "Download/Docs". */
    fun treeDisplayName(treeUri: String): String = try {
        val id = DocumentsContract.getTreeDocumentId(Uri.parse(treeUri))
        val root = id.substringBefore(':')
        val path = id.substringAfter(':', "")
        val prefix = if (root.equals("primary", ignoreCase = true)) "" else "[$root] "
        prefix + path.ifEmpty { "/" }
    } catch (e: Exception) {
        treeUri
    }

    data class StorageSpace(val totalBytes: Long, val freeBytes: Long)

    fun primaryStorageSpace(): StorageSpace? = try {
        val stat = StatFs(Environment.getExternalStorageDirectory().absolutePath)
        StorageSpace(stat.totalBytes, stat.availableBytes)
    } catch (e: Exception) {
        null
    }
}
