package hr.smartduplicatecleaner.ui.home

import android.Manifest
import android.content.ActivityNotFoundException
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ViewModule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import hr.smartduplicatecleaner.AppContainer
import hr.smartduplicatecleaner.BuildConfig
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.ui.components.DonateFab
import hr.smartduplicatecleaner.core.scan.ScanPhase
import hr.smartduplicatecleaner.data.ResultsRepository
import hr.smartduplicatecleaner.data.db.SummaryEntity
import hr.smartduplicatecleaner.data.settings.AppSettings
import hr.smartduplicatecleaner.scan.ScanState
import hr.smartduplicatecleaner.storage.MediaAccess
import hr.smartduplicatecleaner.storage.StorageAccess
import hr.smartduplicatecleaner.ui.components.DisplayPrefs
import hr.smartduplicatecleaner.ui.components.NoticeCard
import hr.smartduplicatecleaner.ui.components.SectionTitle
import hr.smartduplicatecleaner.ui.components.StatTile
import hr.smartduplicatecleaner.ui.components.formatDateTime
import hr.smartduplicatecleaner.ui.components.formatSize
import hr.smartduplicatecleaner.ui.components.warningText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    container: AppContainer,
    onReview: () -> Unit,
    onSettings: () -> Unit,
    onFolders: () -> Unit,
    onRecovery: () -> Unit
) {
    val context = LocalContext.current
    val scanState by container.scanManager.state.collectAsState()
    val summary by container.results.summary.collectAsState(initial = null)
    val settings by container.settings.settings.collectAsState(initial = AppSettings())
    val prefs = DisplayPrefs(settings.sizeUnit, settings.europeanDates)

    // Stanje dopuštenja osvježava se pri svakom povratku na zaslon (npr. iz sistemskih postavki).
    var refresh by remember { mutableIntStateOf(0) }
    LifecycleResumeEffect(Unit) {
        refresh++
        onPauseOrDispose { }
    }
    val mediaAccess = remember(refresh) { StorageAccess.mediaAccess(context) }
    val allFiles = remember(refresh) { StorageAccess.hasAllFilesAccess() }
    var askedOnce by rememberSaveable { mutableStateOf(false) }
    var showAllFilesDialog by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        askedOnce = true
        refresh++
    }
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        container.scanManager.start()
    }

    fun startScan() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !StorageAccess.hasNotificationPermission(context)) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            container.scanManager.start()
        }
    }

    Scaffold(
        // Gumb za donaciju sa strane (iznad donjih gumba).
        floatingActionButton = { if (BuildConfig.SHOW_DONATE) DonateFab() },
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.nav_cleaner_title)) },
                actions = {
                    IconButton(onClick = onRecovery) { Icon(Icons.Filled.Restore, stringResource(R.string.recovery_title)) }
                    IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, stringResource(R.string.settings)) }
                }
            )
        },
        bottomBar = {
            // Glavne radnje na dnu zaslona – dohvatljive palcem pri radu jednom rukom.
            Surface(tonalElevation = 3.dp) {
                Column(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val running = scanState is ScanState.Running
                    Button(
                        onClick = { if (running) container.scanManager.cancel() else startScan() },
                        modifier = Modifier.fillMaxWidth().height(60.dp)
                    ) {
                        Icon(Icons.Filled.Search, null)
                        Spacer(Modifier.size(8.dp))
                        Text(
                            stringResource(if (running) R.string.cancel_scan else R.string.scan_files),
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton(onClick = onReview, modifier = Modifier.weight(1f).height(52.dp), enabled = !running) {
                            Icon(Icons.Filled.ViewModule, null)
                            Spacer(Modifier.size(6.dp))
                            Text(stringResource(R.string.review_duplicates))
                        }
                        OutlinedButton(onClick = onSettings, modifier = Modifier.weight(1f).height(52.dp)) {
                            Icon(Icons.Filled.Settings, null)
                            Spacer(Modifier.size(6.dp))
                            Text(stringResource(R.string.settings))
                        }
                    }
                }
            }
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ScanStatusCard(scanState, prefs, onReview = {
                container.scanManager.acknowledge(); onReview()
            }, onDismiss = { container.scanManager.acknowledge() })

            SummaryCard(summary, prefs)

            summary?.let { s ->
                if (s.skippedPotentialDuplicates > 0 && s.maxFileSizeBytes != null) {
                    NoticeCard(
                        stringResource(
                            R.string.notice_size_limit,
                            s.skippedPotentialDuplicates,
                            formatSize(s.maxFileSizeBytes, prefs)
                        )
                    )
                }
                if (s.skippedByDate > 0) {
                    NoticeCard(stringResource(R.string.notice_date_filter, s.skippedByDate), warning = false)
                }
                ResultsRepository.decodeWarnings(s.warnings).forEach { NoticeCard(warningText(it)) }
            }

            SectionTitle(stringResource(R.string.access_title))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        when (mediaAccess) {
                            MediaAccess.FULL -> stringResource(R.string.access_media_full)
                            MediaAccess.PARTIAL -> stringResource(R.string.access_media_partial)
                            MediaAccess.NONE -> stringResource(R.string.access_media_none)
                        },
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (mediaAccess != MediaAccess.FULL) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { permissionLauncher.launch(StorageAccess.mediaPermissions()) }) {
                                Text(stringResource(R.string.grant_media))
                            }
                            if (askedOnce) {
                                TextButton(onClick = { context.startActivity(StorageAccess.appSettingsIntent(context)) }) {
                                    Text(stringResource(R.string.open_app_settings))
                                }
                            }
                        }
                    }
                    if (BuildConfig.ALLOW_ALL_FILES) {
                        Text(
                            stringResource(if (allFiles) R.string.access_all_files_on else R.string.access_all_files_off),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        if (!allFiles) {
                            OutlinedButton(onClick = { showAllFilesDialog = true }) { Text(stringResource(R.string.enable_all_files)) }
                        }
                    } else {
                        Text(stringResource(R.string.access_documents_via_folders), style = MaterialTheme.typography.bodyMedium)
                    }
                    Text(
                        stringResource(R.string.access_saf_count, settings.safTrees.size),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedButton(onClick = onFolders) {
                        Icon(Icons.Filled.FolderOpen, null)
                        Spacer(Modifier.size(6.dp))
                        Text(stringResource(R.string.manage_folders))
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    if (showAllFilesDialog) {
        AlertDialog(
            onDismissRequest = { showAllFilesDialog = false },
            title = { Text(stringResource(R.string.all_files_dialog_title)) },
            text = { Text(stringResource(R.string.all_files_dialog_text)) },
            confirmButton = {
                TextButton(onClick = {
                    showAllFilesDialog = false
                    try {
                        context.startActivity(StorageAccess.allFilesAccessIntent(context))
                    } catch (e: ActivityNotFoundException) {
                        context.startActivity(StorageAccess.allFilesAccessFallbackIntent())
                    }
                }) { Text(stringResource(R.string.open_system_settings)) }
            },
            dismissButton = { TextButton(onClick = { showAllFilesDialog = false }) { Text(stringResource(R.string.not_now)) } }
        )
    }
}

@Composable
private fun ScanStatusCard(state: ScanState, prefs: DisplayPrefs, onReview: () -> Unit, onDismiss: () -> Unit) {
    when (state) {
        is ScanState.Running -> Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val p = state.progress
                Text(
                    when (p?.phase) {
                        ScanPhase.LISTING, null -> stringResource(R.string.phase_listing)
                        ScanPhase.HASHING -> stringResource(R.string.phase_hashing)
                        ScanPhase.ANALYZING_IMAGES -> stringResource(R.string.phase_images)
                        ScanPhase.GROUPING -> stringResource(R.string.phase_grouping)
                        ScanPhase.FINISHED -> stringResource(R.string.phase_finished)
                    },
                    style = MaterialTheme.typography.titleMedium
                )
                if (p != null && p.total > 0) {
                    LinearProgressIndicator(progress = { p.processed.toFloat() / p.total }, modifier = Modifier.fillMaxWidth())
                    Text(stringResource(R.string.progress_of, p.processed, p.total), style = MaterialTheme.typography.bodySmall)
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                Text(stringResource(R.string.files_examined, p?.filesFound ?: 0))
                Text(stringResource(R.string.duplicates_so_far, p?.duplicatesFound ?: 0))
                Text(stringResource(R.string.reclaimable_estimate, formatSize(p?.reclaimableBytes ?: 0, prefs)))
            }
        }
        is ScanState.Finished -> Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            NoticeCard(
                stringResource(R.string.scan_done, state.stats.duplicateFiles, formatSize(state.stats.reclaimableBytes, prefs)),
                warning = false
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.ok)) }
                Button(onClick = onReview) { Text(stringResource(R.string.review_duplicates)) }
            }
        }
        is ScanState.Cancelled -> NoticeCard(stringResource(R.string.scan_cancelled))
        is ScanState.Failed -> NoticeCard(stringResource(R.string.scan_failed, state.message))
        ScanState.Idle -> Unit
    }
}

@Composable
private fun SummaryCard(summary: SummaryEntity?, prefs: DisplayPrefs) {
    val space = remember { StorageAccess.primaryStorageSpace() }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.overview), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            if (space != null) {
                val used = space.totalBytes - space.freeBytes
                LinearProgressIndicator(
                    progress = { if (space.totalBytes > 0) used.toFloat() / space.totalBytes else 0f },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    stringResource(R.string.storage_used, formatSize(used, prefs), formatSize(space.totalBytes, prefs)),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            if (summary == null) {
                Text(stringResource(R.string.never_scanned), style = MaterialTheme.typography.bodyMedium)
            } else {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    StatTile(stringResource(R.string.stat_duplicates), summary.duplicateFiles.toString(), Modifier.weight(1f))
                    StatTile(stringResource(R.string.stat_reclaimable), formatSize(summary.reclaimableBytes, prefs), Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                    StatTile(stringResource(R.string.stat_analyzed), formatSize(summary.analyzedBytes, prefs), Modifier.weight(1f))
                    StatTile(stringResource(R.string.stat_files), summary.filesAnalyzed.toString(), Modifier.weight(1f))
                }
                Text(
                    stringResource(R.string.last_scan, formatDateTime(summary.finishedAt, prefs)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
