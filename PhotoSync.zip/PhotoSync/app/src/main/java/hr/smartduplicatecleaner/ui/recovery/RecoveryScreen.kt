package hr.smartduplicatecleaner.ui.recovery

import android.app.Activity
import android.content.IntentSender
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import hr.smartduplicatecleaner.AppContainer
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.data.db.RecoveryEntity
import hr.smartduplicatecleaner.deletion.DeletionManager
import hr.smartduplicatecleaner.deletion.RecoveryMethod
import hr.smartduplicatecleaner.ui.components.DisplayPrefs
import hr.smartduplicatecleaner.ui.components.NoticeCard
import hr.smartduplicatecleaner.ui.components.formatDateTime
import hr.smartduplicatecleaner.ui.components.formatSize
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Oporavak: vraćanje ili trajno brisanje datoteka iz koša / mape za oporavak. */
class RecoveryViewModel(private val c: AppContainer) : ViewModel() {
    private val dm get() = c.deletionManager

    /** Poruka kao ID resursa + argumenti – prevodi je sučelje na trenutačnom jeziku. */
    data class Msg(val res: Int, val args: List<Any>)

    data class UiState(val loading: Boolean = true, val items: List<RecoveryEntity> = emptyList())

    private val _state = MutableStateFlow(UiState())
    val state = _state.asStateFlow()
    private val _messages = MutableSharedFlow<Msg>(extraBufferCapacity = 4)
    val messages = _messages.asSharedFlow()
    private val _consent = MutableStateFlow<IntentSender?>(null)
    val consent = _consent.asStateFlow()

    private enum class Pending { RESTORE, PURGE }
    private var pending: Pair<Pending, List<RecoveryEntity>>? = null

    init { load() }

    fun load() {
        viewModelScope.launch {
            val (ok, stale) = withContext(Dispatchers.IO) {
                dm.allRecords().partition { dm.isRecoverable(it) }
            }
            // Zapisi bez stvarno sačuvane kopije (npr. koš ispražnjen nakon 30 dana) se uklanjaju.
            if (stale.isNotEmpty()) {
                dm.removeRecords(stale.map { it.id })
                _messages.tryEmit(Msg(R.string.recovery_stale_removed, listOf(stale.size)))
            }
            _state.value = UiState(false, ok.sortedByDescending { it.deletedAt })
        }
    }

    fun restore(items: List<RecoveryEntity>) = run(Pending.RESTORE, items)
    fun purge(items: List<RecoveryEntity>) = run(Pending.PURGE, items)

    private fun run(action: Pending, items: List<RecoveryEntity>) {
        viewModelScope.launch {
            val local = items.filter { it.method != RecoveryMethod.MEDIA_TRASH }
            val media = items.filter { it.method == RecoveryMethod.MEDIA_TRASH }
            var okCount = 0
            withContext(Dispatchers.IO) {
                val done = local.filter {
                    try {
                        if (action == Pending.RESTORE) dm.restoreLocal(it) else dm.purgeLocal(it)
                    } catch (e: Exception) {
                        false
                    }
                }
                dm.removeRecords(done.map { it.id })
                okCount = done.size
            }
            if (local.isNotEmpty()) {
                _messages.tryEmit(Msg(R.string.recovery_result, listOf(okCount, local.size)))
            }
            if (media.isNotEmpty()) {
                val uris = media.mapNotNull { it.mediaUri }.map { Uri.parse(it) }
                try {
                    val pi = if (action == Pending.RESTORE) dm.mediaRestoreRequest(uris) else dm.mediaRequest(uris, trash = false)
                    pending = action to media
                    _consent.value = pi.intentSender
                } catch (e: Exception) {
                    _messages.tryEmit(Msg(R.string.recovery_result, listOf(0, media.size)))
                }
            }
            if (media.isEmpty()) load()
        }
    }

    fun onConsentResult(approved: Boolean) {
        _consent.value = null
        val (action, items) = pending ?: return
        pending = null
        viewModelScope.launch {
            val done = withContext(Dispatchers.IO) {
                items.filter { e ->
                    val st = dm.mediaState(Uri.parse(e.mediaUri ?: ""))
                    if (action == Pending.RESTORE) st == DeletionManager.MediaState.PRESENT else st == DeletionManager.MediaState.GONE
                }
            }
            dm.removeRecords(done.map { it.id })
            _messages.tryEmit(
                if (!approved && done.isEmpty()) Msg(R.string.fail_declined, emptyList())
                else Msg(R.string.recovery_result, listOf(done.size, items.size))
            )
            load()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecoveryScreen(vm: RecoveryViewModel, prefs: DisplayPrefs, onBack: () -> Unit) {
    val context = LocalContext.current
    val state by vm.state.collectAsState()
    val consent by vm.consent.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    var confirmPurgeAll by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(context.getString(it.res, *it.args.toTypedArray())) } }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
        vm.onConsentResult(it.resultCode == Activity.RESULT_OK)
    }
    LaunchedEffect(consent) {
        consent?.let { launcher.launch(IntentSenderRequest.Builder(it).build()) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.recovery_title)) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } },
                actions = {
                    if (state.items.isNotEmpty()) TextButton(onClick = { confirmPurgeAll = true }) { Text(stringResource(R.string.empty_recovery)) }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { padding ->
        when {
            state.loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            else -> LazyColumn(
                Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item { NoticeCard(stringResource(R.string.recovery_info), warning = false) }
                if (state.items.isEmpty()) item { Text(stringResource(R.string.recovery_empty), Modifier.padding(16.dp)) }
                items(state.items, key = { it.id }) { e ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(e.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(e.displayPath, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(
                                formatSize(e.sizeBytes, prefs) + " · " + formatDateTime(e.deletedAt, prefs) + " · " +
                                    stringResource(if (e.method == RecoveryMethod.MEDIA_TRASH) R.string.recovery_in_trash else R.string.recovery_in_folder),
                                style = MaterialTheme.typography.bodySmall
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { vm.restore(listOf(e)) }) { Text(stringResource(R.string.restore)) }
                                TextButton(onClick = { vm.purge(listOf(e)) }) { Text(stringResource(R.string.delete_permanently)) }
                            }
                        }
                    }
                }
            }
        }
    }

    if (confirmPurgeAll) {
        AlertDialog(
            onDismissRequest = { confirmPurgeAll = false },
            title = { Text(stringResource(R.string.empty_recovery)) },
            text = { Text(stringResource(R.string.empty_recovery_confirm, state.items.size)) },
            confirmButton = { TextButton(onClick = { confirmPurgeAll = false; vm.purge(state.items) }) { Text(stringResource(R.string.delete_permanently)) } },
            dismissButton = { TextButton(onClick = { confirmPurgeAll = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}
