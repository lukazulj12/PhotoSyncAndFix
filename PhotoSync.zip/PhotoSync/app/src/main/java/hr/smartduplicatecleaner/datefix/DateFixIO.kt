package hr.smartduplicatecleaner.datefix

import android.content.ContentUris
import android.content.Context
import android.database.Cursor
import android.media.MediaScannerConnection
import android.net.Uri
import android.provider.MediaStore
import android.system.Os
import androidx.exifinterface.media.ExifInterface
import hr.smartduplicatecleaner.core.logic.FileClassifier
import hr.smartduplicatecleaner.core.media.FileRandomAccessIO
import hr.smartduplicatecleaner.core.media.Mp4Dates
import hr.smartduplicatecleaner.core.media.RandomAccessIO
import hr.smartduplicatecleaner.core.model.DateSource
import hr.smartduplicatecleaner.core.model.FileCategory
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.core.model.SourceType
import hr.smartduplicatecleaner.storage.StorageAccess
import java.io.File
import java.io.FileDescriptor
import java.io.RandomAccessFile
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

/** Mapa s brojem fotografija i videozapisa. */
data class MediaFolder(val relativeDir: String, val count: Int)

/** Čitanje fotografija i videozapisa iz MediaStorea za ispravak datuma. */
object DateFixMedia {

    private fun collections(volume: String, photos: Boolean, videos: Boolean) = buildList {
        if (photos) add(FileCategory.IMAGE to MediaStore.Images.Media.getContentUri(volume))
        if (videos) add(FileCategory.VIDEO to MediaStore.Video.Media.getContentUri(volume))
    }

    /** Sve mape s fotografijama/videozapisima i broj datoteka u njima. */
    fun folders(context: Context, photos: Boolean = true, videos: Boolean = true): List<MediaFolder> {
        val counts = sortedMapOf<String, Int>(String.CASE_INSENSITIVE_ORDER)
        for (volume in MediaStore.getExternalVolumeNames(context)) {
            for ((_, uri) in collections(volume, photos, videos)) {
                try {
                    context.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.RELATIVE_PATH), null, null, null)?.use { c ->
                        while (c.moveToNext()) {
                            val dir = StorageAccess.normalizeDir(c.getString(0) ?: continue)
                            counts[dir] = (counts[dir] ?: 0) + 1
                        }
                    }
                } catch (e: Exception) { /* bez dopuštenja – prazno */ }
            }
        }
        return counts.map { MediaFolder(it.key, it.value) }
    }

    /** Fotografije i videozapisi u odabranim mapama (prazan skup = sve mape, uključujući podmape). */
    fun files(context: Context, folders: Set<String>, photos: Boolean = true, videos: Boolean = true): List<ScannedFile> {
        val wanted = folders.map { it.trim('/').lowercase() + "/" }
        val result = mutableListOf<ScannedFile>()
        val projection = arrayOf(
            MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.RELATIVE_PATH,
            MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.DATE_ADDED,
            MediaStore.MediaColumns.DATE_MODIFIED, MediaStore.MediaColumns.DATE_TAKEN, MediaStore.MediaColumns.DATA
        )
        for (volume in MediaStore.getExternalVolumeNames(context)) {
            for ((category, uri) in collections(volume, photos, videos)) {
                try {
                    context.contentResolver.query(uri, projection, null, null, null)?.use { c ->
                        while (c.moveToNext()) {
                            val name = c.getString(1) ?: continue
                            val dir = StorageAccess.normalizeDir(c.str(2).orEmpty())
                            if (StorageAccess.isProtectedDir(dir)) continue
                            if (wanted.isNotEmpty() && wanted.none { dir.lowercase().startsWith(it) }) continue
                            val taken = c.lng(7)?.takeIf { it > 0 }
                            result += ScannedFile(
                                key = StorageAccess.canonicalKey(volume, dir, name),
                                uri = ContentUris.withAppendedId(uri, c.getLong(0)).toString(),
                                source = SourceType.MEDIA_STORE,
                                name = name,
                                volume = volume,
                                relativeDir = dir,
                                sizeBytes = c.lng(3) ?: 0L,
                                mimeType = c.str(4),
                                category = category,
                                dateTakenMillis = taken,
                                dateTakenSource = taken?.let { DateSource.MEDIA_METADATA },
                                dateAddedMillis = c.lng(5)?.takeIf { it > 0 }?.times(1000),
                                dateModifiedMillis = c.lng(6)?.takeIf { it > 0 }?.times(1000),
                                absolutePath = c.str(8)
                            )
                        }
                    }
                } catch (e: Exception) { /* nedostupan volumen */ }
            }
        }
        return result
    }

    private fun Cursor.str(i: Int): String? = if (isNull(i)) null else getString(i)
    private fun Cursor.lng(i: Int): Long? = if (isNull(i)) null else getLong(i)
}

/** Rezultat upisa datuma za jednu datoteku. */
data class DateWriteResult(
    val file: ScannedFile,
    val metadataWritten: Boolean,
    val modifiedWritten: Boolean,
    val error: String?
) {
    val ok: Boolean get() = metadataWritten || modifiedWritten
}

/**
 * Upis datuma:
 *  - fotografije JPG/PNG/WEBP: EXIF DateTimeOriginal/Digitized/DateTime (+ vremenska zona)
 *  - videozapisi MP4/MOV/3GP/M4V: datum stvaranja u kutijama mvhd/tkhd/mdhd
 *  - datum izmjene datoteke: samo uz "Pristup svim datotekama" (inačica full)
 * Bez pristupa svim datotekama upisuje se preko MediaStorea, nakon što korisnik odobri izmjenu u sistemskom dijalogu.
 */
class DateWriter(private val context: Context) {
    private val resolver get() = context.contentResolver

    fun canWriteDirect(file: ScannedFile): Boolean {
        val path = file.absolutePath ?: return false
        return StorageAccess.hasAllFilesAccess() && File(path).let { it.exists() && it.canWrite() }
    }

    fun write(file: ScannedFile, targetMillis: Long, writeMetadata: Boolean, writeModified: Boolean): DateWriteResult {
        val ext = FileClassifier.extension(file.name)
        val direct = canWriteDirect(file)
        var meta = false
        var modified = false
        var error: String? = null
        if (writeMetadata) {
            try {
                when (ext) {
                    in EXIF_EXT -> { if (direct) exifPath(file.absolutePath!!, targetMillis) else exifUri(Uri.parse(file.uri), targetMillis); meta = true }
                    in MP4_EXT -> { if (direct) mp4Path(file.absolutePath!!, targetMillis) else mp4Uri(Uri.parse(file.uri), targetMillis); meta = true }
                    else -> error = UNSUPPORTED
                }
            } catch (e: Mp4Dates.NotMp4Exception) {
                error = UNSUPPORTED
            } catch (e: SecurityException) {
                error = NO_PERMISSION
            } catch (e: Exception) {
                error = e.message ?: e.javaClass.simpleName
            }
        }
        if (writeModified && direct) {
            modified = File(file.absolutePath!!).setLastModified(targetMillis)
            if (!modified && error == null) error = MTIME_FAILED
        }
        if (direct && (meta || modified)) {
            // MediaStore ponovno čita datoteku → galerija prikazuje novi datum.
            MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath!!), null, null)
        }
        return DateWriteResult(file, meta, modified, if (meta || modified) null else error ?: UNSUPPORTED)
    }

    private fun exifValues(exif: ExifInterface, millis: Long) {
        val zdt = Instant.ofEpochMilli(millis).atZone(ZoneId.systemDefault())
        val text = zdt.format(EXIF_FORMAT)
        val offset = zdt.offset.id.let { if (it == "Z") "+00:00" else it }
        exif.setAttribute(ExifInterface.TAG_DATETIME_ORIGINAL, text)
        exif.setAttribute(ExifInterface.TAG_DATETIME_DIGITIZED, text)
        exif.setAttribute(ExifInterface.TAG_DATETIME, text)
        exif.setAttribute(ExifInterface.TAG_OFFSET_TIME_ORIGINAL, offset)
        exif.setAttribute(ExifInterface.TAG_OFFSET_TIME_DIGITIZED, offset)
        exif.setAttribute(ExifInterface.TAG_OFFSET_TIME, offset)
        exif.saveAttributes()
    }

    private fun exifPath(path: String, millis: Long) = exifValues(ExifInterface(path), millis)

    private fun exifUri(uri: Uri, millis: Long) {
        resolver.openFileDescriptor(uri, "rw")?.use { pfd -> exifValues(ExifInterface(pfd.fileDescriptor), millis) }
            ?: throw java.io.FileNotFoundException(uri.toString())
    }

    private fun mp4Path(path: String, millis: Long) {
        RandomAccessFile(path, "rw").use { Mp4Dates.write(FileRandomAccessIO(it), millis) }
    }

    private fun mp4Uri(uri: Uri, millis: Long) {
        resolver.openFileDescriptor(uri, "rw")?.use { pfd -> Mp4Dates.write(FdIO(pfd.fileDescriptor), millis) }
            ?: throw java.io.FileNotFoundException(uri.toString())
    }

    /** pread/pwrite nad opisnikom datoteke iz MediaStorea. */
    class FdIO(private val fd: FileDescriptor) : RandomAccessIO {
        override val size: Long get() = Os.fstat(fd).st_size
        override fun read(position: Long, buffer: ByteArray, offset: Int, length: Int): Int =
            Os.pread(fd, buffer, offset, length, position)
        override fun write(position: Long, buffer: ByteArray, offset: Int, length: Int) {
            var done = 0
            while (done < length) {
                val n = Os.pwrite(fd, buffer, offset + done, length - done, position + done)
                if (n <= 0) throw java.io.IOException("pwrite")
                done += n
            }
        }
    }

    companion object {
        val EXIF_EXT = setOf("jpg", "jpeg", "png", "webp")
        val MP4_EXT = setOf("mp4", "m4v", "mov", "3gp", "3g2")
        const val UNSUPPORTED = "unsupported"
        const val NO_PERMISSION = "permission"
        const val MTIME_FAILED = "mtime"
        private val EXIF_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyy:MM:dd HH:mm:ss")
    }
}
