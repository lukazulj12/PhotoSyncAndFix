package hr.smartduplicatecleaner.ui.results

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import hr.smartduplicatecleaner.R
import hr.smartduplicatecleaner.core.hash.PerceptualHash
import hr.smartduplicatecleaner.core.logic.Reason
import hr.smartduplicatecleaner.core.model.DuplicateGroup
import hr.smartduplicatecleaner.core.model.ScannedFile
import hr.smartduplicatecleaner.ui.components.DisplayPrefs
import hr.smartduplicatecleaner.ui.components.FileStatus
import hr.smartduplicatecleaner.ui.components.FileThumbnail
import hr.smartduplicatecleaner.ui.components.InfoLine
import hr.smartduplicatecleaner.ui.components.NoticeCard
import hr.smartduplicatecleaner.ui.components.StatusBadge
import hr.smartduplicatecleaner.ui.components.dateSourceLabel
import hr.smartduplicatecleaner.ui.components.formatDateTime
import hr.smartduplicatecleaner.ui.components.formatSize
import hr.smartduplicatecleaner.ui.components.groupTypeDescription
import hr.smartduplicatecleaner.ui.components.groupTypeLabel
import hr.smartduplicatecleaner.ui.components.reasonText
import hr.smartduplicatecleaner.ui.components.statusBorder
import hr.smartduplicatecleaner.ui.theme.LocalStatusColors

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupDetailScreen(
    vm: ReviewViewModel,
    groupId: String,
    prefs: DisplayPrefs,
    onBack: () -> Unit,
    onOpenGroup: (String) -> Unit,
    onCompare: (groupId: String, index: Int) -> Unit
) {
    val state by vm.state.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    val context = LocalContext.current
    LaunchedEffect(Unit) { vm.messages.collect { snackbar.showSnackbar(context.getString(it)) } }
    var gridMode by rememberSaveable { mutableStateOf(true) }

    val visible = state.visibleGroups
    val group = state.groups.firstOrNull { it.id == groupId }
    val index = visible.indexOfFirst { it.id == groupId }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    val title = when {
                        group == null -> ""
                        index >= 0 -> groupTypeLabel(group.type) + "  ${index + 1}/${visible.size}"
                        else -> groupTypeLabel(group.type)
                    }
                    Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.back)) } },
                actions = {
                    IconButton(onClick = { gridMode = !gridMode }) {
                        Icon(
                            if (gridMode) Icons.AutoMirrored.Filled.ViewList else Icons.Filled.GridView,
                            stringResource(if (gridMode) R.string.detail_view else R.string.grid_view)
                        )
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Row(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { visible.getOrNull(index - 1)?.let { onOpenGroup(it.id) } },
                        enabled = index > 0,
                        modifier = Modifier.weight(1f).height(52.dp)
                    ) { Icon(Icons.Filled.ChevronLeft, null); Text(stringResource(R.string.previous)) }
                    Spacer(Modifier.size(8.dp))
                    OutlinedButton(
                        onClick = { visible.getOrNull(index + 1)?.let { onOpenGroup(it.id) } },
                        enabled = index >= 0 && index < visible.size - 1,
                        modifier = Modifier.weight(1f).height(52.dp)
                    ) { Text(stringResource(R.string.next)); Icon(Icons.Filled.ChevronRight, null) }
                }
            }
        }
    ) { padding ->
        if (group == null) {
            Text(stringResource(R.string.group_not_found), Modifier.padding(padding).padding(24.dp))
            return@Scaffold
        }
        val files = group.fileKeys.mapNotNull { state.files[it] }
        val decision = state.decisions[group.id]
        val multiContent = group.members.map { it.contentLabel }.distinct().size > 1
        LazyVerticalGrid(
            columns = GridCells.Fixed(if (gridMode) 2 else 1),
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(groupTypeDescription(group.type), style = MaterialTheme.typography.bodyMedium)
                    group.maxDistance?.let {
                        Text(stringResource(R.string.similarity_percent, PerceptualHash.similarityPercent(it)), style = MaterialTheme.typography.bodySmall)
                    }
                    if (decision?.needsManual == true && group.fileKeys.none { it in state.marked }) {
                        NoticeCard(stringResource(R.string.manual_decision_needed))
                    }
                    decision?.notes?.filter { it.code != hr.smartduplicatecleaner.core.logic.ReasonCode.NO_CLEAR_WINNER }?.forEach {
                        Text("• " + reasonText(it), style = MaterialTheme.typography.bodySmall)
                    }
                    Row {
                        TextButton(onClick = { vm.clearGroup(group.id) }) { Text(stringResource(R.string.clear_group_marks)) }
                    }
                }
            }
            itemsIndexed(files, key = { _, f -> f.key }) { i, f ->
                val status = state.status(group.id, f.key)
                val reasons = decision?.members?.firstOrNull { it.fileKey == f.key }?.reasons.orEmpty()
                val label = group.members.firstOrNull { it.fileKey == f.key }?.contentLabel
                FileCard(
                    file = f,
                    status = status,
                    reasons = reasons,
                    contentLabel = if (multiContent) label else null,
                    compact = gridMode,
                    prefs = prefs,
                    onKeepOnly = { vm.keepOnly(group.id, f.key) },
                    onToggle = { vm.toggle(f.key) },
                    onZoom = { onCompare(group.id, i) }
                )
            }
        }
    }
}

@Composable
private fun FileCard(
    file: ScannedFile,
    status: FileStatus,
    reasons: List<Reason>,
    contentLabel: Int?,
    compact: Boolean,
    prefs: DisplayPrefs,
    onKeepOnly: () -> Unit,
    onToggle: () -> Unit,
    onZoom: () -> Unit
) {
    val marked = status == FileStatus.DELETE_SUGGESTED || status == FileStatus.DELETE_MANUAL
    val sc = LocalStatusColors.current
    Card(Modifier.fillMaxWidth().statusBorder(status)) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Column(Modifier.clickable(onClick = onZoom)) {
                FileThumbnail(
                    file,
                    Modifier.fillMaxWidth().aspectRatio(if (compact) 1f else 4f / 3f),
                    sizePx = if (compact) 400 else 900
                )
            }
            StatusBadge(status)
            Text(file.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, maxLines = if (compact) 2 else 4, overflow = TextOverflow.Ellipsis)
            if (contentLabel != null) {
                Text(stringResource(R.string.content_label, ('A' + contentLabel).toString()), style = MaterialTheme.typography.labelMedium)
            }
            val taken = file.dateTakenMillis
            val takenText = when {
                taken == null -> stringResource(R.string.not_available)
                compact -> formatDateTime(taken, prefs)
                else -> formatDateTime(taken, prefs) + " (" + dateSourceLabel(file.dateTakenSource?.name) + ")"
            }
            InfoLine(stringResource(R.string.date_taken), takenText, emphasize = true)
            InfoLine(stringResource(R.string.size), formatSize(file.sizeBytes, prefs), emphasize = true)
            if (file.width != null && file.height != null) {
                InfoLine(stringResource(R.string.resolution), "${file.width} × ${file.height}")
            }
            if (!compact) {
                InfoLine(
                    stringResource(R.string.date_modified),
                    file.dateModifiedMillis?.let { formatDateTime(it, prefs) } ?: stringResource(R.string.not_available)
                )
                InfoLine(
                    stringResource(R.string.date_added),
                    file.dateAddedMillis?.let { formatDateTime(it, prefs) } ?: stringResource(R.string.not_available)
                )
                InfoLine(stringResource(R.string.folder), file.relativeDir.ifEmpty { "/" })
                if (file.volume != null && file.volume != "external_primary") InfoLine(stringResource(R.string.storage), file.volume!!)
            } else {
                Text(file.relativeDir.ifEmpty { "/" }, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (reasons.isNotEmpty()) {
                Text(stringResource(R.string.reason), style = MaterialTheme.typography.labelMedium)
                reasons.take(if (compact) 2 else 6).forEach { Text("• " + reasonText(it), style = MaterialTheme.typography.bodySmall) }
            }
            // Jedan dodir: zadrži ovu datoteku (ostale u grupi označavaju se za brisanje).
            Button(
                onClick = onKeepOnly,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = sc.keep, contentColor = sc.onKeep)
            ) { Text(stringResource(R.string.keep_this_file), maxLines = 1, overflow = TextOverflow.Ellipsis) }
            Row(Modifier.fillMaxWidth().clickable(onClick = onToggle), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = marked, onCheckedChange = { onToggle() })
                Text(stringResource(R.string.mark_for_deletion), style = MaterialTheme.typography.bodySmall)
            }
            if (!compact) {
                OutlinedButton(onClick = onZoom, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Filled.ZoomIn, null); Spacer(Modifier.size(6.dp)); Text(stringResource(R.string.compare_fullscreen))
                }
            }
        }
    }
}
